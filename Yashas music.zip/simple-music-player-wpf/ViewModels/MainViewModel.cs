﻿using Microsoft.Win32;
using MusicPlayerApp.WPF.Helpers;
using MusicPlayerApp.WPF.Models;
using MusicPlayerApp.WPF.Services;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace MusicPlayerApp.WPF.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged, IDisposable
    {
        public ObservableCollection<Track> Tracks { get; } = new ObservableCollection<Track>();
        private readonly PlayerService _playerService;

        public MainViewModel()
        {
            _playerService = new PlayerService();
            _playerService.PositionChanged += (s, pos) => Position = pos;
            _playerService.DurationChanged += (s, dur) => Duration = dur;
            _playerService.TrackChanged += (s, path) => NowPlayingText = $"Playing: {System.IO.Path.GetFileName(path)}";
            _playerService.MediaEnded += (s, e) => IsPlaying = false;
            _playerService.MediaOpened += (s, e) => { /* handled by DurationChanged */ };

            SelectSongsCommand = new RelayCommand(_ => SelectSongs());
            PlayCommand = new RelayCommand(async _ => await PlayAsync(), _ => SelectedTrack != null);
            PauseCommand = new RelayCommand(_ => Pause(), _ => IsPlaying);
            StopCommand = new RelayCommand(_ => Stop(), _ => IsPlaying);
            NextCommand = new RelayCommand(async _ => await PlayNextAsync(), _ => Tracks.Any());
            PrevCommand = new RelayCommand(async _ => await PlayPrevAsync(), _ => Tracks.Any());

            Volume = 0.5;
            _playerService.SetVolume(Volume);
        }

        private Track? _selectedTrack;
        public Track? SelectedTrack
        {
            get => _selectedTrack;
            set
            {
                if (_selectedTrack != value)
                {
                    _selectedTrack = value;
                    OnPropertyChanged();
                    NowPlayingText = _selectedTrack == null ? "Nothing selected" : $"Selected: {_selectedTrack.Title}";
                    PlayCommand.RaiseCanExecuteChanged();
                }
            }
        }

        private string _nowPlayingText = "Nothing selected";
        public string NowPlayingText
        {
            get => _nowPlayingText;
            set { _nowPlayingText = value; OnPropertyChanged(); }
        }

        // Position & Duration
        private TimeSpan _position;
        public TimeSpan Position
        {
            get => _position;
            set { _position = value; OnPropertyChanged(); OnPropertyChanged(nameof(PositionPercent)); }
        }

        private TimeSpan _duration;
        public TimeSpan Duration
        {
            get => _duration;
            set { _duration = value; OnPropertyChanged(); OnPropertyChanged(nameof(PositionPercent)); }
        }

        public double PositionPercent => Duration.TotalSeconds == 0 ? 0 : Position.TotalSeconds / Duration.TotalSeconds;

        // Seek property bound to Slider (TwoWay)
        public double SeekPosition
        {
            get => PositionPercent;
            set => SeekToPercent(value);
        }

        // Volume
        private double _volume;
        public double Volume
        {
            get => _volume;
            set
            {
                if (_volume == value) return;
                _volume = value;
                _playerService.SetVolume(value);
                OnPropertyChanged();
            }
        }

        // Playback state exposed to UI
        private bool _isPlaying;
        public bool IsPlaying
        {
            get => _isPlaying;
            set
            {
                if (_isPlaying == value) return;
                _isPlaying = value;
                OnPropertyChanged();
                // Update button enabled states
                PauseCommand.RaiseCanExecuteChanged();
                StopCommand.RaiseCanExecuteChanged();
            }
        }

        // Commands
        public RelayCommand SelectSongsCommand { get; }
        public RelayCommand PlayCommand { get; }
        public RelayCommand PauseCommand { get; }
        public RelayCommand StopCommand { get; }
        public RelayCommand NextCommand { get; }
        public RelayCommand PrevCommand { get; }

        private void SelectSongs()
        {
            var dlg = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "Audio Files|*.mp3;*.wav;*.wma;*.aac;*.m4a"
            };

            if (dlg.ShowDialog() == true)
            {
                Tracks.Clear();
                foreach (var f in dlg.FileNames)
                    Tracks.Add(new Track { Title = System.IO.Path.GetFileName(f), Path = f });

                if (Tracks.Count > 0)
                {
                    SelectedTrack = Tracks[0];
                    _playerService.SetPlaylist(Tracks.Select(t => t.Path));
                    // update Next/Prev availability
                    NextCommand.RaiseCanExecuteChanged();
                    PrevCommand.RaiseCanExecuteChanged();
                }
            }
        }

        private async Task PlayAsync()
        {
            if (SelectedTrack == null) return;

            var current = _playerService.GetCurrentTrack();
            if (current == null || current != SelectedTrack.Path)
            {
                _playerService.SetPlaylist(Tracks.Select(t => t.Path));
            }

            var ok = await _playerService.PlayAsync(SelectedTrack.Path);
            if (!ok)
            {
                NowPlayingText = "Failed to open file";
                return;
            }

            Duration = _playerService.GetDuration();
            IsPlaying = true;
            NowPlayingText = $"Playing: {SelectedTrack.Title}";

            PlayCommand.RaiseCanExecuteChanged();
            PauseCommand.RaiseCanExecuteChanged();
            StopCommand.RaiseCanExecuteChanged();
        }

        private void Pause()
        {
            _playerService.Pause();
            IsPlaying = false;
            NowPlayingText = "Paused";
        }

        private void Stop()
        {
            _playerService.Stop();
            Position = TimeSpan.Zero;
            IsPlaying = false;
            NowPlayingText = "Stopped";
        }

        private async Task PlayNextAsync()
        {
            if (Tracks.Count == 0) return;
            await _playerService.PlayNextAsync();
            var cur = _playerService.GetCurrentTrack();
            if (cur != null)
            {
                SelectedTrack = Tracks.FirstOrDefault(t => t.Path == cur);
                Duration = _playerService.GetDuration();
                IsPlaying = true;
            }
        }

        private async Task PlayPrevAsync()
        {
            if (Tracks.Count == 0) return;
            await _playerService.PlayPrevAsync();
            var cur = _playerService.GetCurrentTrack();
            if (cur != null)
            {
                SelectedTrack = Tracks.FirstOrDefault(t => t.Path == cur);
                Duration = _playerService.GetDuration();
                IsPlaying = true;
            }
        }

        private void SeekToPercent(double percent)
        {
            if (Duration.TotalSeconds == 0) return;
            var seconds = Duration.TotalSeconds * percent;
            _playerService.Seek(seconds);
            // Position will update via PositionChanged event shortly
        }

        // INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        public void Dispose() => _playerService.Dispose();
    }
}
