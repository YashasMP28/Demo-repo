using System.Windows;

namespace MusicPlayerApp.WPF
{
    public partial class App : Application
    {
    }
}
