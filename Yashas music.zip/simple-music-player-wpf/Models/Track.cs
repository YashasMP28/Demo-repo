namespace MusicPlayerApp.WPF.Models
{
    public class Track
    {
        public string Title { get; set; } = string.Empty;
        public string Path { get; set; } = string.Empty;
        // optional metadata fields you can fill later:
        // public string Artist { get; set; } = string.Empty;
        // public string Album { get; set; } = string.Empty;
    }
}
