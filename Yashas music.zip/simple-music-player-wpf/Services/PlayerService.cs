using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Threading;

namespace MusicPlayerApp.WPF.Services
{
    public class PlayerService : IDisposable
    {
        private readonly MediaPlayer _player = new MediaPlayer();
        private readonly DispatcherTimer _timer;
        private List<string> _playlist = new();
        private int _currentIndex = -1;

        public bool IsPlaying { get; private set; }

        public event EventHandler<TimeSpan>? PositionChanged;
        public event EventHandler<TimeSpan>? DurationChanged;
        public event EventHandler<string>? TrackChanged;
        public event EventHandler? MediaOpened;
        public event EventHandler? MediaEnded;

        public PlayerService()
        {
            _player.MediaOpened += (s, e) =>
            {
                if (_player.NaturalDuration.HasTimeSpan)
                    DurationChanged?.Invoke(this, _player.NaturalDuration.TimeSpan);

                MediaOpened?.Invoke(this, EventArgs.Empty);
                TrackChanged?.Invoke(this, GetCurrentTrack() ?? "Unknown");
            };

            _player.MediaEnded += (s, e) =>
            {
                MediaEnded?.Invoke(this, EventArgs.Empty);
                _ = PlayNextAsync(); // auto next
            };

            // Update position 4 times per second
            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(250)
            };
            _timer.Tick += (s, e) =>
            {
                PositionChanged?.Invoke(this, _player.Position);
            };
        }

        // ------------------------
        // PLAYLIST CONTROL
        // ------------------------

        public void SetPlaylist(IEnumerable<string> paths)
        {
            _playlist = paths.ToList();
            _currentIndex = _playlist.Count > 0 ? 0 : -1;
        }

        public string? GetCurrentTrack()
        {
            if (_currentIndex < 0 || _currentIndex >= _playlist.Count)
                return null;

            return _playlist[_currentIndex];
        }

        // ------------------------
        // CORE PLAY METHODS
        // ------------------------

        public async Task<bool> PlayAsync(string path)
        {
            try
            {
                _player.Open(new Uri(path));

                // WAIT for MediaOpened
                bool opened = await WaitForMediaOpened();
                if (!opened) return false;

                _player.Play();
                IsPlaying = true;
                _timer.Start();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task PlayNextAsync()
        {
            if (_playlist.Count == 0) return;

            _currentIndex = (_currentIndex + 1) % _playlist.Count;
            await PlayAsync(_playlist[_currentIndex]);
        }

        public async Task PlayPrevAsync()
        {
            if (_playlist.Count == 0) return;

            _currentIndex = (_currentIndex - 1 + _playlist.Count) % _playlist.Count;
            await PlayAsync(_playlist[_currentIndex]);
        }

        // Timeout-based wait for MediaOpened to occur
        private Task<bool> WaitForMediaOpened()
        {
            var tcs = new TaskCompletionSource<bool>();
            bool opened = false;

            EventHandler handler = null!;
            handler = (s, e) =>
            {
                opened = true;
                MediaOpened -= handler;
                tcs.TrySetResult(true);
            };

            MediaOpened += handler;

            // Timeout
            Task.Delay(2000).ContinueWith(_ =>
            {
                if (!opened)
                {
                    MediaOpened -= handler;
                    tcs.TrySetResult(false);
                }
            });

            return tcs.Task;
        }

        public void Pause()
        {
            _player.Pause();
            IsPlaying = false;
        }

        public void Stop()
        {
            _player.Stop();
            IsPlaying = false;
            _timer.Stop();
        }

        public void Seek(double seconds)
        {
            _player.Position = TimeSpan.FromSeconds(seconds);
        }

        public TimeSpan GetDuration() =>
            _player.NaturalDuration.HasTimeSpan ? _player.NaturalDuration.TimeSpan : TimeSpan.Zero;

        public TimeSpan GetPosition() => _player.Position;

        public void SetVolume(double v) => _player.Volume = v;


        public void Dispose()
        {
            _timer.Stop();
            _player.Close();
        }
    }
}
