﻿using Microsoft.Win32;
using MusicPlayerApp.WPF.Helpers;
using MusicPlayerApp.WPF.Models;
using MusicPlayerApp.WPF.Services;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace MusicPlayerApp.WPF.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged, IDisposable
    {
        private readonly PlayerService _playerService;
        private bool _isUserSeeking;

        public ObservableCollection<Track> Tracks { get; } = new ObservableCollection<Track>();

        public MainViewModel()
        {
            _playerService = new PlayerService();

            // Subscribe to player events
            _playerService.PositionChanged += OnPositionChanged;
            _playerService.DurationChanged += OnDurationChanged;
            _playerService.TrackChanged += OnTrackChanged;
            _playerService.MediaEnded += OnMediaEnded;
            _playerService.MediaOpened += OnMediaOpened;

            // Initialize commands
            SelectSongsCommand = new RelayCommand(_ => SelectSongs());
            PlayCommand = new RelayCommand(async _ => await PlayAsync(), _ => SelectedTrack != null);
            PauseCommand = new RelayCommand(_ => Pause(), _ => IsPlaying);
            StopCommand = new RelayCommand(_ => Stop(), _ => IsPlaying || IsPaused);
            NextCommand = new RelayCommand(async _ => await PlayNextAsync(), _ => Tracks.Count > 1);
            PrevCommand = new RelayCommand(async _ => await PlayPrevAsync(), _ => Tracks.Count > 1);

            // Set initial volume
            Volume = 0.5;
            _playerService.SetVolume(Volume);
        }

        #region Properties

        private Track? _selectedTrack;
        public Track? SelectedTrack
        {
            get => _selectedTrack;
            set
            {
                if (_selectedTrack != value)
                {
                    _selectedTrack = value;
                    OnPropertyChanged();
                    UpdateNowPlayingText();
                    PlayCommand.RaiseCanExecuteChanged();
                }
            }
        }

        private string _nowPlayingText = "No track selected";
        public string NowPlayingText
        {
            get => _nowPlayingText;
            set
            {
                if (_nowPlayingText != value)
                {
                    _nowPlayingText = value;
                    OnPropertyChanged();
                }
            }
        }

        private TimeSpan _position;
        public TimeSpan Position
        {
            get => _position;
            set
            {
                if (_position != value)
                {
                    _position = value;
                    OnPropertyChanged();
                    if (!_isUserSeeking)
                    {
                        OnPropertyChanged(nameof(SeekPosition));
                    }
                }
            }
        }

        private TimeSpan _duration;
        public TimeSpan Duration
        {
            get => _duration;
            set
            {
                if (_duration != value)
                {
                    _duration = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(SeekPosition));
                }
            }
        }

        public double SeekPosition
        {
            get => Duration.TotalSeconds > 0 ? Position.TotalSeconds / Duration.TotalSeconds : 0;
            set
            {
                _isUserSeeking = true;
                SeekToPercent(value);
                _isUserSeeking = false;
            }
        }

        private double _volume;
        public double Volume
        {
            get => _volume;
            set
            {
                if (Math.Abs(_volume - value) > 0.001)
                {
                    _volume = value;
                    _playerService.SetVolume(value);
                    OnPropertyChanged();
                }
            }
        }

        private bool _isPlaying;
        public bool IsPlaying
        {
            get => _isPlaying;
            set
            {
                if (_isPlaying != value)
                {
                    _isPlaying = value;
                    if (value) IsPaused = false;
                    OnPropertyChanged();
                    UpdateCommandStates();
                }
            }
        }

        private bool _isPaused;
        public bool IsPaused
        {
            get => _isPaused;
            set
            {
                if (_isPaused != value)
                {
                    _isPaused = value;
                    OnPropertyChanged();
                    UpdateCommandStates();
                }
            }
        }

        #endregion

        #region Commands

        public RelayCommand SelectSongsCommand { get; }
        public RelayCommand PlayCommand { get; }
        public RelayCommand PauseCommand { get; }
        public RelayCommand StopCommand { get; }
        public RelayCommand NextCommand { get; }
        public RelayCommand PrevCommand { get; }

        #endregion

        #region Command Methods

        private void SelectSongs()
        {
            var dlg = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "Audio Files|*.mp3;*.wav;*.wma;*.aac;*.m4a;*.flac;*.ogg|All Files|*.*",
                Title = "Select Music Files"
            };

            if (dlg.ShowDialog() == true)
            {
                Tracks.Clear();
                foreach (var filePath in dlg.FileNames)
                {
                    Tracks.Add(new Track
                    {
                        Title = Path.GetFileNameWithoutExtension(filePath),
                        Path = filePath
                    });
                }

                if (Tracks.Count > 0)
                {
                    SelectedTrack = Tracks[0];
                    _playerService.SetPlaylist(Tracks.Select(t => t.Path));
                    UpdateCommandStates();
                }
            }
        }

        private async Task PlayAsync()
        {
            if (SelectedTrack == null) return;

            // If paused, just resume
            if (IsPaused && _playerService.GetCurrentTrack() == SelectedTrack.Path)
            {
                _playerService.Play();
                IsPlaying = true;
                IsPaused = false;
                NowPlayingText = $"▶ {SelectedTrack.Title}";
                return;
            }

            // Otherwise load and play the track
            var currentTrack = _playerService.GetCurrentTrack();
            if (currentTrack != SelectedTrack.Path)
            {
                _playerService.SetPlaylist(Tracks.Select(t => t.Path));
            }

            var success = await _playerService.PlayAsync(SelectedTrack.Path);
            if (!success)
            {
                NowPlayingText = "⚠ Failed to load track";
                return;
            }

            IsPlaying = true;
            Duration = _playerService.GetDuration();
        }

        private void Pause()
        {
            _playerService.Pause();
            IsPlaying = false;
            IsPaused = true;
            if (SelectedTrack != null)
            {
                NowPlayingText = $"⏸ {SelectedTrack.Title} (Paused)";
            }
        }

        private void Stop()
        {
            _playerService.Stop();
            Position = TimeSpan.Zero;
            IsPlaying = false;
            IsPaused = false;
            NowPlayingText = SelectedTrack != null ? $"⏹ {SelectedTrack.Title} (Stopped)" : "No track selected";
        }

        private async Task PlayNextAsync()
        {
            if (Tracks.Count <= 1) return;

            await _playerService.PlayNextAsync();
            SyncSelectedTrackWithPlayer();
        }

        private async Task PlayPrevAsync()
        {
            if (Tracks.Count <= 1) return;

            await _playerService.PlayPrevAsync();
            SyncSelectedTrackWithPlayer();
        }

        private void SeekToPercent(double percent)
        {
            if (Duration.TotalSeconds <= 0) return;
            var seconds = Duration.TotalSeconds * Math.Clamp(percent, 0, 1);
            _playerService.Seek(seconds);
        }

        #endregion

        #region Event Handlers

        private void OnPositionChanged(object? sender, TimeSpan position)
        {
            Position = position;
        }

        private void OnDurationChanged(object? sender, TimeSpan duration)
        {
            Duration = duration;
        }

        private void OnTrackChanged(object? sender, string trackPath)
        {
            var track = Tracks.FirstOrDefault(t => t.Path == trackPath);
            if (track != null)
            {
                NowPlayingText = $"▶ {track.Title}";
            }
        }

        private void OnMediaEnded(object? sender, EventArgs e)
        {
            // Auto-play next track is handled in PlayerService
        }

        private void OnMediaOpened(object? sender, EventArgs e)
        {
            Duration = _playerService.GetDuration();
        }

        #endregion

        #region Helper Methods

        private void UpdateNowPlayingText()
        {
            if (SelectedTrack == null)
            {
                NowPlayingText = "No track selected";
            }
            else if (IsPlaying)
            {
                NowPlayingText = $"▶ {SelectedTrack.Title}";
            }
            else if (IsPaused)
            {
                NowPlayingText = $"⏸ {SelectedTrack.Title} (Paused)";
            }
            else
            {
                NowPlayingText = SelectedTrack.Title;
            }
        }

        private void SyncSelectedTrackWithPlayer()
        {
            var currentPath = _playerService.GetCurrentTrack();
            if (currentPath != null)
            {
                SelectedTrack = Tracks.FirstOrDefault(t => t.Path == currentPath);
                Duration = _playerService.GetDuration();
                IsPlaying = true;
            }
        }

        private void UpdateCommandStates()
        {
            PlayCommand.RaiseCanExecuteChanged();
            PauseCommand.RaiseCanExecuteChanged();
            StopCommand.RaiseCanExecuteChanged();
            NextCommand.RaiseCanExecuteChanged();
            PrevCommand.RaiseCanExecuteChanged();
        }

        #endregion

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            _playerService.PositionChanged -= OnPositionChanged;
            _playerService.DurationChanged -= OnDurationChanged;
            _playerService.TrackChanged -= OnTrackChanged;
            _playerService.MediaEnded -= OnMediaEnded;
            _playerService.MediaOpened -= OnMediaOpened;
            _playerService.Dispose();
        }

        #endregion
    }
}