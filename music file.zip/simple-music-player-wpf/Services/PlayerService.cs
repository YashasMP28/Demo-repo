using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Threading;

namespace MusicPlayerApp.WPF.Services
{
    public class PlayerService : IDisposable
    {
        private readonly MediaPlayer _player;
        private readonly DispatcherTimer _positionTimer;
        private List<string> _playlist = new();
        private int _currentIndex = -1;
        private bool _isDisposed;

        public bool IsPlaying { get; private set; }

        public event EventHandler<TimeSpan>? PositionChanged;
        public event EventHandler<TimeSpan>? DurationChanged;
        public event EventHandler<string>? TrackChanged;
        public event EventHandler? MediaOpened;
        public event EventHandler? MediaEnded;

        public PlayerService()
        {
            _player = new MediaPlayer();

            _player.MediaOpened += OnMediaOpened;
            _player.MediaEnded += OnMediaEnded;
            _player.MediaFailed += OnMediaFailed;

            _positionTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(100)
            };
            _positionTimer.Tick += OnPositionTimerTick;
        }

        #region Playlist Management

        public void SetPlaylist(IEnumerable<string> paths)
        {
            _playlist = paths?.ToList() ?? new List<string>();
            _currentIndex = _playlist.Count > 0 ? 0 : -1;
        }

        public string? GetCurrentTrack()
        {
            if (_currentIndex < 0 || _currentIndex >= _playlist.Count)
                return null;
            return _playlist[_currentIndex];
        }

        #endregion

        #region Playback Control

        public async Task<bool> PlayAsync(string path)
        {
            try
            {
                if (string.IsNullOrEmpty(path))
                    return false;

                // Find track in playlist
                var index = _playlist.IndexOf(path);
                if (index >= 0)
                    _currentIndex = index;

                _player.Open(new Uri(path));

                var opened = await WaitForMediaOpenedAsync();
                if (!opened)
                    return false;

                _player.Play();
                IsPlaying = true;
                _positionTimer.Start();

                return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"PlayAsync failed: {ex.Message}");
                return false;
            }
        }

        public void Play()
        {
            if (_player.Source != null)
            {
                _player.Play();
                IsPlaying = true;
                _positionTimer.Start();
            }
        }

        public void Pause()
        {
            _player.Pause();
            IsPlaying = false;
        }

        public void Stop()
        {
            _player.Stop();
            IsPlaying = false;
            _positionTimer.Stop();
            _player.Position = TimeSpan.Zero;
            PositionChanged?.Invoke(this, TimeSpan.Zero);
        }

        public async Task PlayNextAsync()
        {
            if (_playlist.Count == 0)
                return;

            _currentIndex = (_currentIndex + 1) % _playlist.Count;
            await PlayAsync(_playlist[_currentIndex]);
        }

        public async Task PlayPrevAsync()
        {
            if (_playlist.Count == 0)
                return;

            _currentIndex = (_currentIndex - 1 + _playlist.Count) % _playlist.Count;
            await PlayAsync(_playlist[_currentIndex]);
        }

        public void Seek(double seconds)
        {
            if (_player.NaturalDuration.HasTimeSpan)
            {
                var duration = _player.NaturalDuration.TimeSpan;
                var targetPosition = TimeSpan.FromSeconds(Math.Clamp(seconds, 0, duration.TotalSeconds));
                _player.Position = targetPosition;
            }
        }

        #endregion

        #region Properties

        public TimeSpan GetDuration()
        {
            return _player.NaturalDuration.HasTimeSpan
                ? _player.NaturalDuration.TimeSpan
                : TimeSpan.Zero;
        }

        public TimeSpan GetPosition()
        {
            return _player.Position;
        }

        public void SetVolume(double volume)
        {
            _player.Volume = Math.Clamp(volume, 0, 1);
        }

        #endregion

        #region Event Handlers

        private void OnMediaOpened(object? sender, EventArgs e)
        {
            if (_player.NaturalDuration.HasTimeSpan)
            {
                DurationChanged?.Invoke(this, _player.NaturalDuration.TimeSpan);
            }

            MediaOpened?.Invoke(this, EventArgs.Empty);

            var currentTrack = GetCurrentTrack();
            if (!string.IsNullOrEmpty(currentTrack))
            {
                TrackChanged?.Invoke(this, currentTrack);
            }
        }

        private void OnMediaEnded(object? sender, EventArgs e)
        {
            IsPlaying = false;
            _positionTimer.Stop();
            MediaEnded?.Invoke(this, EventArgs.Empty);

            // Auto-play next track
            _ = PlayNextAsync();
        }

        private void OnMediaFailed(object? sender, ExceptionEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine($"Media failed: {e.ErrorException?.Message}");
            IsPlaying = false;
            _positionTimer.Stop();
        }

        private void OnPositionTimerTick(object? sender, EventArgs e)
        {
            PositionChanged?.Invoke(this, _player.Position);
        }

        #endregion

        #region Helper Methods

        private Task<bool> WaitForMediaOpenedAsync()
        {
            var tcs = new TaskCompletionSource<bool>();
            var timeout = TimeSpan.FromSeconds(5);
            var startTime = DateTime.Now;
            bool handled = false;

            EventHandler openedHandler = null!;
            EventHandler<ExceptionEventArgs> failedHandler = null!;

            openedHandler = (s, e) =>
            {
                if (!handled)
                {
                    handled = true;
                    MediaOpened -= openedHandler;
                    _player.MediaFailed -= failedHandler;
                    tcs.TrySetResult(true);
                }
            };

            failedHandler = (s, e) =>
            {
                if (!handled)
                {
                    handled = true;
                    MediaOpened -= openedHandler;
                    _player.MediaFailed -= failedHandler;
                    tcs.TrySetResult(false);
                }
            };

            MediaOpened += openedHandler;
            _player.MediaFailed += failedHandler;

            // Timeout fallback
            Task.Delay(timeout).ContinueWith(_ =>
            {
                if (!handled)
                {
                    handled = true;
                    MediaOpened -= openedHandler;
                    _player.MediaFailed -= failedHandler;
                    tcs.TrySetResult(false);
                }
            });

            return tcs.Task;
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_isDisposed)
                return;

            _positionTimer?.Stop();
            _player?.Close();
            _isDisposed = true;
        }

        #endregion
    }
}