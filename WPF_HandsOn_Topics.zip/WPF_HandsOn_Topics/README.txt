WPF_HandsOn_Topics

Structure:
1_DependencyProperty_Sample/   -> WPF sample showing a CustomTextControl with a DependencyProperty (InitialText)
2_ThemeSwitch_Sample/          -> WPF sample that loads an image and switches light/dark theme based on average brightness
3_CSharp_OOP_Fundamentals/    -> Console app demonstrating class, interface, inheritance, polymorphism
4_CSharp_Basics/              -> Console app demonstrating data types, strings, arrays, loops

How to open:
- Open each WPF sample as a WPF Application project in Visual Studio (create a new WPF project and replace the default files
  or add these files into a new project with appropriate csproj targeting .NET 8).
- Console apps: create new Console Application projects and replace Program.cs with the provided ones.

All files include inline comments to help you learn. If you want, I can convert each WPF sample into a ready .csproj and solution files too.
