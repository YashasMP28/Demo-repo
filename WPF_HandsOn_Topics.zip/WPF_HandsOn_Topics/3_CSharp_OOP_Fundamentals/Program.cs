using System;

namespace CS_OOP_Fundamentals
{
    // Interface: defines a contract
    interface IWorker
    {
        void DoWork();
    }

    // Base class (parent)
    class Person
    {
        public string Name { get; set; }
        public Person(string name) => Name = name;
        public virtual void Introduce()
        {
            Console.WriteLine($"Hi, I'm {Name} (Person)");
        }
    }

    // Derived class (child) - inherits from Person and implements IWorker
    class Developer : Person, IWorker
    {
        public string Language { get; set; }
        public Developer(string name, string language) : base(name)
        {
            Language = language;
        }

        // Override virtual method (polymorphism)
        public override void Introduce()
        {
            Console.WriteLine($"Hi, I'm {Name}, a developer who loves {Language}.");
        }

        // Interface implementation
        public void DoWork()
        {
            Console.WriteLine($"{Name} is writing {Language} code...");
        }
    }

    class Program
    {
        static void Main()
        {
            // Create objects
            Person p = new Person("Alice");
            p.Introduce();

            Developer d = new Developer("Bob", "C#");
            d.Introduce();
            d.DoWork();

            // Polymorphism: base reference to derived object
            Person poly = new Developer("Charlie", "Python");
            poly.Introduce(); // Calls overridden method

            // Upcasting and explicit downcasting
            IWorker worker = new Developer("Dana", "JavaScript");
            worker.DoWork();

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
