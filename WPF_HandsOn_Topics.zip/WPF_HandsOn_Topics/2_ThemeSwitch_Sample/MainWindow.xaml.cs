using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ThemeSwitchSample
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Load default (light) theme
            ApplyTheme("Themes/LightTheme.xaml");
        }

        private void LoadImage_Click(object sender, RoutedEventArgs e)
        {
            // Let user pick an image
            var dlg = new OpenFileDialog { Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp" };
            if (dlg.ShowDialog() != true) return;

            try
            {
                var bitmap = new BitmapImage(new Uri(dlg.FileName));
                DisplayImage.Source = bitmap;

                // Compute simple brightness and switch theme
                double brightness = ComputeAverageBrightness(bitmap);
                StatusText.Text = $"Average brightness: {brightness:F2}";

                if (brightness < 0.5)
                    ApplyTheme("Themes/DarkTheme.xaml");
                else
                    ApplyTheme("Themes/LightTheme.xaml");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load image: " + ex.Message);
            }
        }

        // Loads a ResourceDictionary theme (XAML) and applies it as merged dictionary
        private void ApplyTheme(string relativePath)
        {
            try
            {
                var uri = new Uri(relativePath, UriKind.Relative);
                var dict = new ResourceDictionary() { Source = uri };

                // Clear previous theme dictionaries (simple approach)
                Application.Current.Resources.MergedDictionaries.Clear();
                Application.Current.Resources.MergedDictionaries.Add(dict);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to apply theme: " + ex.Message);
            }
        }

        // Computes average brightness of a BitmapImage (normalized 0..1)
        private double ComputeAverageBrightness(BitmapImage bitmap)
        {
            try
            {
                // Convert to Format32bppPbgra if needed
                FormatConvertedBitmap formatted = new FormatConvertedBitmap(bitmap, PixelFormats.Bgra32, null, 0);

                int width = formatted.PixelWidth;
                int height = formatted.PixelHeight;
                int stride = width * 4;
                byte[] pixels = new byte[height * stride];
                formatted.CopyPixels(pixels, stride, 0);

                long total = 0;
                int count = 0;
                for (int i = 0; i < pixels.Length; i += 4)
                {
                    byte b = pixels[i];
                    byte g = pixels[i + 1];
                    byte r = pixels[i + 2];
                    // Luma approximation
                    int lum = (int)(0.2126 * r + 0.7152 * g + 0.0722 * b);
                    total += lum;
                    count++;
                }

                double avg = (double)total / (count * 255.0);
                return avg;
            }
            catch
            {
                // If pixel access fails, fallback to neutral brightness
                return 0.6;
            }
        }
    }
}
