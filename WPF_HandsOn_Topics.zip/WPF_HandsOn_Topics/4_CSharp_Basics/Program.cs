using System;

namespace CS_Basics
{
    class Program
    {
        static void Main()
        {
            // Basic data types
            int a = 10;
            double d = 3.14;
            bool flag = true;
            char c = 'A';
            string s = "Hello, bujji!";

            Console.WriteLine($"int: {a}, double: {d}, bool: {flag}, char: {c}, string: {s}");

            // String operations
            Console.WriteLine("Upper: " + s.ToUpper());
            Console.WriteLine("Substring(7): " + s.Substring(7));

            // Arrays
            int[] numbers = new int[] { 1, 2, 3, 4, 5 };
            Console.WriteLine("Array elements:");
            foreach (var num in numbers)
                Console.WriteLine(num);

            // 2D array
            int[,] matrix = { {1,2}, {3,4} };
            Console.WriteLine($"matrix[1,0] = {matrix[1,0]}"); // prints 3

            // Loops
            Console.WriteLine("For loop:");
            for (int i = 0; i < 3; i++)
                Console.WriteLine(i);

            Console.WriteLine("While loop:");
            int x = 0;
            while (x < 3)
            {
                Console.WriteLine(x);
                x++;
            }

            // Simple method usage
            Console.WriteLine($"5! = {Factorial(5)}");

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }

        static int Factorial(int n)
        {
            if (n <= 1) return 1;
            return n * Factorial(n - 1);
        }
    }
}
