using System.Windows;
using System.Windows.Controls;

namespace DependencyPropertySample
{
    /// <summary>
    /// CustomTextControl demonstrates how to declare and use a DependencyProperty.
    /// This control inherits from TextBox and exposes a DependencyProperty called InitialText.
    /// - InitialText acts as an initial/default value (you can set it in XAML or code).
    /// - When the control loads, if its Text is blank, we set Text = InitialText.
    /// Note: This is educational — dependency properties offer many more features, including change callbacks, default metadata, data binding, etc.
    /// </summary>
    public class CustomTextControl : TextBox
    {
        // Register a DependencyProperty named InitialText of type string.
        public static readonly DependencyProperty InitialTextProperty =
            DependencyProperty.Register(
                nameof(InitialText),              // property name
                typeof(string),                   // property type
                typeof(CustomTextControl),        // owner type
                new PropertyMetadata(string.Empty) // default value
            );

        // CLR wrapper for easier usage in code
        public string InitialText
        {
            get => (string)GetValue(InitialTextProperty);
            set => SetValue(InitialTextProperty, value);
        }

        public CustomTextControl()
        {
            // When control finishes loading, if the Text is empty, set it to InitialText.
            this.Loaded += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(this.Text))
                {
                    this.Text = InitialText;
                    // Place caret at end so user can type after default text (optional)
                    this.CaretIndex = this.Text?.Length ?? 0;
                }
            };
        }
    }
}
