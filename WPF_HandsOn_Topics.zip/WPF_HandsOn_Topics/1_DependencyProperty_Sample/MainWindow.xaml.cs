using System.Windows;

namespace DependencyPropertySample
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // You can also read/set the dependency property from code:
            // string initial = customBox.InitialText;
            // customBox.InitialText = "new default";
        }
    }
}
