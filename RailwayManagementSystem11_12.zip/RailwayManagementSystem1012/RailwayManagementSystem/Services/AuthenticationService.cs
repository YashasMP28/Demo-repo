﻿

using RailwayManagementSystem.Models;

namespace RailwayManagementSystem.Services
{
    public static class AuthenticationService
    {
        private static User _currentUser;
        private static readonly JsonDataService _dataService = new JsonDataService();

        public static User Login(string email, string password)
        {
            var user = _dataService.GetUserByEmail(email);

            if (user != null && user.Password == password)
            {
                _currentUser = user;
                return user;
            }

            return null;
        }

        public static bool Register(User newUser)
        {
            var existingUser = _dataService.GetUserByEmail(newUser.Email);

            if (existingUser != null)
            {
                return false; 
            }

            newUser.IsAdmin = false; 
            _dataService.AddUser(newUser);
            return true;
        }

        public static User CurrentUser
        {
            get { return _currentUser; }
            set { _currentUser = value; }
        }

        public static void Logout()
        {
            _currentUser = null;
        }
    }
}