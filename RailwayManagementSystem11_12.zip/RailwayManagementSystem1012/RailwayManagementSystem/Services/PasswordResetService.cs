﻿using RailwayManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RailwayManagementSystem.Services
{
    // -------- NEWLY ADDED CODE --------
    /// <summary>
    /// Password Reset Service for handling forgot password workflow
    /// Generates reset tokens, validates them, and updates user passwords
    /// </summary>
    public class PasswordResetService
    {
        private readonly JsonDataService _dataService;

        // In-memory token storage: Key=ResetToken, Value=(Email, ExpirationTime)
        private static Dictionary<string, (string Email, DateTime ExpiryTime)> _resetTokenStorage =
            new Dictionary<string, (string, DateTime)>();

        // Token validity duration in minutes
        private const int TOKEN_VALIDITY_MINUTES = 30;

        public PasswordResetService()
        {
            _dataService = new JsonDataService();
        }

        /// <summary>
        /// Initiates password reset process for a user
        /// Verifies email and phone number match an existing user
        /// </summary>
        public (bool Success, string Message, string ResetToken) InitiatePasswordReset(string email, string phoneNumber)
        {
            try
            {
                // Validate user exists with matching email and phone
                var user = _dataService.GetUserByEmail(email);

                if (user == null)
                {
                    return (false, "Email not found in our system.", null);
                }

                if (user.Phone != phoneNumber)
                {
                    return (false, "Email and phone number do not match our records.", null);
                }

                // Generate reset token
                string resetToken = GenerateResetToken();

                // Store token with expiration
                DateTime expiryTime = DateTime.Now.AddMinutes(TOKEN_VALIDITY_MINUTES);

                if (_resetTokenStorage.ContainsKey(resetToken))
                {
                    _resetTokenStorage[resetToken] = (email, expiryTime);
                }
                else
                {
                    _resetTokenStorage.Add(resetToken, (email, expiryTime));
                }

                Console.WriteLine($"Password reset initiated for {email}. Token: {resetToken}");

                return (true, "Password reset instructions have been sent to your email.", resetToken);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Password reset initiation error: {ex.Message}");
                return (false, "An error occurred. Please try again.", null);
            }
        }

        /// <summary>
        /// Generates a random reset token (alphanumeric, 32 characters)
        /// </summary>
        private static string GenerateResetToken()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            Random random = new Random();
            return new string(Enumerable.Range(0, 32)
                .Select(_ => chars[random.Next(chars.Length)])
                .ToArray());
        }

        /// <summary>
        /// Validates the reset token
        /// </summary>
        public bool ValidateResetToken(string resetToken)
        {
            try
            {
                if (!_resetTokenStorage.ContainsKey(resetToken))
                {
                    Console.WriteLine("Invalid reset token.");
                    return false;
                }

                var (email, expiryTime) = _resetTokenStorage[resetToken];

                // Check if token has expired
                if (DateTime.Now > expiryTime)
                {
                    Console.WriteLine("Reset token has expired.");
                    _resetTokenStorage.Remove(resetToken);
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Token validation error: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Resets the user's password using a valid token
        /// </summary>
        public (bool Success, string Message) ResetPassword(string resetToken, string newPassword, string confirmPassword)
        {
            try
            {
                // Validate token
                if (!ValidateResetToken(resetToken))
                {
                    return (false, "Invalid or expired reset token.");
                }

                // Validate password match
                if (newPassword != confirmPassword)
                {
                    return (false, "Passwords do not match.");
                }

                // Validate password strength (minimum 6 characters)
                if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 6)
                {
                    return (false, "Password must be at least 6 characters long.");
                }

                // Get email from token
                var (email, _) = _resetTokenStorage[resetToken];

                // Get user and update password
                var user = _dataService.GetUserByEmail(email);
                if (user == null)
                {
                    return (false, "User not found.");
                }

                // Update password
                user.Password = newPassword;
                _dataService.UpdateUser(user);

                // Remove token after successful reset
                _resetTokenStorage.Remove(resetToken);

                Console.WriteLine($"Password reset successfully for {email}");
                return (true, "Password has been reset successfully. Please log in with your new password.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Password reset error: {ex.Message}");
                return (false, "An error occurred while resetting password.");
            }
        }

        /// <summary>
        /// Gets the email associated with a reset token
        /// </summary>
        public string GetEmailFromToken(string resetToken)
        {
            if (_resetTokenStorage.ContainsKey(resetToken))
            {
                return _resetTokenStorage[resetToken].Email;
            }
            return null;
        }

        /// <summary>
        /// Clears expired reset tokens
        /// </summary>
        public static void ClearExpiredTokens()
        {
            try
            {
                var expiredKeys = _resetTokenStorage
                    .Where(x => DateTime.Now > x.Value.ExpiryTime)
                    .Select(x => x.Key)
                    .ToList();

                foreach (var key in expiredKeys)
                {
                    _resetTokenStorage.Remove(key);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error clearing expired tokens: {ex.Message}");
            }
        }
    }
    // -------- END OF NEWLY ADDED CODE --------
}