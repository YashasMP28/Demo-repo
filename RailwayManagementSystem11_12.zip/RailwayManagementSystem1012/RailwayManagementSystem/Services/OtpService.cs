﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RailwayManagementSystem.Services
{
    // -------- NEWLY ADDED CODE --------
    /// <summary>
    /// OTP Service for generating, storing, and validating One-Time Passwords
    /// Stores OTPs with expiration time for security
    /// </summary>
    public class OtpService
    {
        // In-memory OTP storage: Key=Email, Value=(OTP, ExpirationTime)
        private static Dictionary<string, (string Otp, DateTime ExpiryTime)> _otpStorage =
            new Dictionary<string, (string, DateTime)>();

        // OTP validity duration in minutes
        private const int OTP_VALIDITY_MINUTES = 10;

        // OTP length
        private const int OTP_LENGTH = 6;

        /// <summary>
        /// Generates a random 6-digit OTP and stores it with expiration time
        /// </summary>
        public static string GenerateOtp(string email)
        {
            try
            {
                Random random = new Random();
                string otp = random.Next(100000, 999999).ToString();

                // Store OTP with expiration time
                DateTime expiryTime = DateTime.Now.AddMinutes(OTP_VALIDITY_MINUTES);

                if (_otpStorage.ContainsKey(email))
                {
                    _otpStorage[email] = (otp, expiryTime);
                }
                else
                {
                    _otpStorage.Add(email, (otp, expiryTime));
                }

                Console.WriteLine($"OTP Generated for {email}: {otp} (Expires at: {expiryTime})");
                return otp;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"OTP generation error: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Validates the OTP provided by user
        /// Checks both OTP value and expiration time
        /// </summary>
        public static bool ValidateOtp(string email, string providedOtp)
        {
            try
            {
                if (!_otpStorage.ContainsKey(email))
                {
                    Console.WriteLine($"No OTP found for email: {email}");
                    return false;
                }

                var (storedOtp, expiryTime) = _otpStorage[email];

                // Check if OTP has expired
                if (DateTime.Now > expiryTime)
                {
                    Console.WriteLine($"OTP expired for {email}");
                    _otpStorage.Remove(email); // Remove expired OTP
                    return false;
                }

                // Check if OTP matches
                if (storedOtp == providedOtp)
                {
                    Console.WriteLine($"OTP validated successfully for {email}");
                    _otpStorage.Remove(email); // Remove OTP after successful validation
                    return true;
                }

                Console.WriteLine($"Invalid OTP for {email}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"OTP validation error: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Clears expired OTPs from storage
        /// </summary>
        public static void ClearExpiredOtps()
        {
            try
            {
                var expiredKeys = _otpStorage
                    .Where(x => DateTime.Now > x.Value.ExpiryTime)
                    .Select(x => x.Key)
                    .ToList();

                foreach (var key in expiredKeys)
                {
                    _otpStorage.Remove(key);
                    Console.WriteLine($"Expired OTP removed for: {key}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error clearing expired OTPs: {ex.Message}");
            }
        }

        /// <summary>
        /// Resends OTP to the same email
        /// </summary>
        public static string ResendOtp(string email)
        {
            try
            {
                // Clear old OTP if exists
                if (_otpStorage.ContainsKey(email))
                {
                    _otpStorage.Remove(email);
                }

                // Generate new OTP
                return GenerateOtp(email);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"OTP resend error: {ex.Message}");
                return null;
            }
        }
    }
    // -------- END OF NEWLY ADDED CODE --------
}