﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RailwayManagementSystem.Models;

namespace RailwayManagementSystem.Services
{
    public interface IDataService
    {
        // User operations
        List<User> GetAllUsers();
        User GetUserById(int id);
        User GetUserByEmail(string email);
        void AddUser(User user);
        void UpdateUser(User user);
        void DeleteUser(int id);

        // Train operations
        List<Train> GetAllTrains();
        Train GetTrainById(int id);
        void AddTrain(Train train);
        void UpdateTrain(Train train);
        void DeleteTrain(int id);

        // Route operations
        List<Route> GetAllRoutes();
        Route GetRouteById(int id);
        void AddRoute(Route route);
        void UpdateRoute(Route route);
        void DeleteRoute(int id);

        // Ticket operations
        List<Ticket> GetAllTickets();
        List<Ticket> GetTicketsByUserId(int userId);
        Ticket GetTicketById(int id);
        void AddTicket(Ticket ticket);
        void UpdateTicket(Ticket ticket);
        void CancelTicket(int ticketId);

        // Passenger operations
        List<Passenger> GetAllPassengers();
        Passenger GetPassengerById(int id);
        void AddPassenger(Passenger passenger);
        void UpdatePassenger(Passenger passenger);
        void DeletePassenger(int id);
    }
}