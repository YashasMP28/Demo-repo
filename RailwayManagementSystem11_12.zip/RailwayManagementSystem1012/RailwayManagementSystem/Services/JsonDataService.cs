﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using RailwayManagementSystem.Models;

namespace RailwayManagementSystem.Services
{
    public class JsonDataService : IDataService
    {
        private readonly string _dataFolder;
        private readonly string _usersFile;
        private readonly string _trainsFile;
        private readonly string _routesFile;
        private readonly string _ticketsFile;
        private readonly string _passengersFile;

        public JsonDataService()
        {
            // Get the application's base directory
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            _dataFolder = Path.Combine(baseDirectory, "Data");

            // Create Data folder if it doesn't exist
            if (!Directory.Exists(_dataFolder))
            {
                Directory.CreateDirectory(_dataFolder);
            }

            _usersFile = Path.Combine(_dataFolder, "users.json");
            _trainsFile = Path.Combine(_dataFolder, "trains.json");
            _routesFile = Path.Combine(_dataFolder, "routes.json");
            _ticketsFile = Path.Combine(_dataFolder, "tickets.json");
            _passengersFile = Path.Combine(_dataFolder, "passengers.json");

            InitializeDataFiles();
        }

        private void InitializeDataFiles()
        {
            // Initialize users.json with admin account
            if (!File.Exists(_usersFile))
            {
                var defaultUsers = new List<User>
                {
                    new User
                    {
                        Id = 1,
                        Username = "admin",
                        Email = "admin@railway.com",
                        Password = "admin123",
                        Address = "Admin Office",
                        Phone = "1234567890",
                        Gender = "Male",
                        IsAdmin = true,
                        CreatedDate = DateTime.Now
                    }
                };
                SaveToFile(_usersFile, defaultUsers);
            }

            // Initialize other files
            if (!File.Exists(_trainsFile))
                SaveToFile(_trainsFile, new List<Train>());

            if (!File.Exists(_routesFile))
                SaveToFile(_routesFile, new List<Route>());

            if (!File.Exists(_ticketsFile))
                SaveToFile(_ticketsFile, new List<Ticket>());

            if (!File.Exists(_passengersFile))
                SaveToFile(_passengersFile, new List<Passenger>());
        }

        private T LoadFromFile<T>(string filePath) where T : new()
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);
                    return JsonConvert.DeserializeObject<T>(json) ?? new T();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading {filePath}: {ex.Message}");
            }
            return new T();
        }

        private void SaveToFile<T>(string filePath, T data)
        {
            try
            {
                string json = JsonConvert.SerializeObject(data, Formatting.Indented);
                File.WriteAllText(filePath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error saving {filePath}: {ex.Message}");
            }
        }

        // User operations
        public List<User> GetAllUsers()
        {
            return LoadFromFile<List<User>>(_usersFile);
        }

        public User GetUserById(int id)
        {
            var users = GetAllUsers();
            return users.FirstOrDefault(u => u.Id == id);
        }

        public User GetUserByEmail(string email)
        {
            var users = GetAllUsers();
            return users.FirstOrDefault(u => u.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
        }

        public void AddUser(User user)
        {
            var users = GetAllUsers();
            user.Id = users.Any() ? users.Max(u => u.Id) + 1 : 1;
            user.CreatedDate = DateTime.Now;
            users.Add(user);
            SaveToFile(_usersFile, users);
        }

        public void UpdateUser(User user)
        {
            var users = GetAllUsers();
            var existingUser = users.FirstOrDefault(u => u.Id == user.Id);
            if (existingUser != null)
            {
                existingUser.Username = user.Username;
                existingUser.Email = user.Email;
                existingUser.Password = user.Password;
                existingUser.Address = user.Address;
                existingUser.Phone = user.Phone;
                existingUser.Gender = user.Gender;
                SaveToFile(_usersFile, users);
            }
        }

        public void DeleteUser(int id)
        {
            var users = GetAllUsers();
            users.RemoveAll(u => u.Id == id);
            SaveToFile(_usersFile, users);
        }

        // Train operations
        public List<Train> GetAllTrains()
        {
            return LoadFromFile<List<Train>>(_trainsFile);
        }

        public Train GetTrainById(int id)
        {
            var trains = GetAllTrains();
            return trains.FirstOrDefault(t => t.TrainId == id);
        }

        public void AddTrain(Train train)
        {
            var trains = GetAllTrains();
            train.TrainId = trains.Any() ? trains.Max(t => t.TrainId) + 1 : 1;
            trains.Add(train);
            SaveToFile(_trainsFile, trains);
        }

        public void UpdateTrain(Train train)
        {
            var trains = GetAllTrains();
            var existingTrain = trains.FirstOrDefault(t => t.TrainId == train.TrainId);
            if (existingTrain != null)
            {
                existingTrain.TrainName = train.TrainName;
                existingTrain.TotalSeats = train.TotalSeats;
                existingTrain.AvailableSeats = train.AvailableSeats;
                SaveToFile(_trainsFile, trains);
            }
        }

        public void DeleteTrain(int id)
        {
            var trains = GetAllTrains();
            trains.RemoveAll(t => t.TrainId == id);
            SaveToFile(_trainsFile, trains);
        }

        // Route operations
        public List<Route> GetAllRoutes()
        {
            return LoadFromFile<List<Route>>(_routesFile);
        }

        public Route GetRouteById(int id)
        {
            var routes = GetAllRoutes();
            return routes.FirstOrDefault(r => r.Id == id);
        }

        public void AddRoute(Route route)
        {
            var routes = GetAllRoutes();
            route.Id = routes.Any() ? routes.Max(r => r.Id) + 1 : 1;
            routes.Add(route);
            SaveToFile(_routesFile, routes);
        }

        public void UpdateRoute(Route route)
        {
            var routes = GetAllRoutes();
            var existingRoute = routes.FirstOrDefault(r => r.Id == route.Id);
            if (existingRoute != null)
            {
                existingRoute.TrainId = route.TrainId;
                existingRoute.TrainName = route.TrainName;
                existingRoute.Source = route.Source;
                existingRoute.Destination = route.Destination;
                existingRoute.Date = route.Date;
                existingRoute.Cost = route.Cost;
                SaveToFile(_routesFile, routes);
            }
        }

        public void DeleteRoute(int id)
        {
            var routes = GetAllRoutes();
            routes.RemoveAll(r => r.Id == id);
            SaveToFile(_routesFile, routes);
        }

        // Ticket operations
        public List<Ticket> GetAllTickets()
        {
            return LoadFromFile<List<Ticket>>(_ticketsFile);
        }

        public List<Ticket> GetTicketsByUserId(int userId)
        {
            var tickets = GetAllTickets();
            return tickets.Where(t => t.UserId == userId).ToList();
        }

        public Ticket GetTicketById(int id)
        {
            var tickets = GetAllTickets();
            return tickets.FirstOrDefault(t => t.TicketId == id);
        }

        public void AddTicket(Ticket ticket)
        {
            var tickets = GetAllTickets();
            ticket.TicketId = tickets.Any() ? tickets.Max(t => t.TicketId) + 1 : 1;
            ticket.BookingDate = DateTime.Now;
            ticket.Status = "Active";
            tickets.Add(ticket);
            SaveToFile(_ticketsFile, tickets);
        }

        public void UpdateTicket(Ticket ticket)
        {
            var tickets = GetAllTickets();
            var existingTicket = tickets.FirstOrDefault(t => t.TicketId == ticket.TicketId);
            if (existingTicket != null)
            {
                existingTicket.RouteId = ticket.RouteId;
                existingTicket.PassengerName = ticket.PassengerName;
                existingTicket.Status = ticket.Status;
                existingTicket.Amount = ticket.Amount;
                SaveToFile(_ticketsFile, tickets);
            }
        }

        public void CancelTicket(int ticketId)
        {
            var tickets = GetAllTickets();
            var ticket = tickets.FirstOrDefault(t => t.TicketId == ticketId);
            if (ticket != null)
            {
                ticket.Status = "Cancelled";
                SaveToFile(_ticketsFile, tickets);
            }
        }

        // Passenger operations
        public List<Passenger> GetAllPassengers()
        {
            return LoadFromFile<List<Passenger>>(_passengersFile);
        }

        public Passenger GetPassengerById(int id)
        {
            var passengers = GetAllPassengers();
            return passengers.FirstOrDefault(p => p.Id == id);
        }

        public void AddPassenger(Passenger passenger)
        {
            var passengers = GetAllPassengers();
            passenger.Id = passengers.Any() ? passengers.Max(p => p.Id) + 1 : 1;
            passengers.Add(passenger);
            SaveToFile(_passengersFile, passengers);
        }

        public void UpdatePassenger(Passenger passenger)
        {
            var passengers = GetAllPassengers();
            var existingPassenger = passengers.FirstOrDefault(p => p.Id == passenger.Id);
            if (existingPassenger != null)
            {
                existingPassenger.Username = passenger.Username;
                existingPassenger.Email = passenger.Email;
                existingPassenger.Password = passenger.Password;
                existingPassenger.Address = passenger.Address;
                existingPassenger.Phone = passenger.Phone;
                existingPassenger.Gender = passenger.Gender;
                SaveToFile(_passengersFile, passengers);
            }
        }

        public void DeletePassenger(int id)
        {
            var passengers = GetAllPassengers();
            passengers.RemoveAll(p => p.Id == id);
            SaveToFile(_passengersFile, passengers);
        }

        public void DeleteTicket(int ticketId)
        {
            var tickets = GetAllTickets();
            var ticketToRemove = tickets.FirstOrDefault(t => t.TicketId == ticketId);

            if (ticketToRemove != null)
            {
                tickets.Remove(ticketToRemove);
                SaveAllTickets(tickets);
            }
        }
        private void SaveAllTickets(List<Ticket> tickets)
        {
            string json = JsonConvert.SerializeObject(tickets, Formatting.Indented);
            File.WriteAllText(_ticketsFile, json);
        }

    }
}