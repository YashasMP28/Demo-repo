﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace RailwayManagementSystem.Services
{
    // -------- NEWLY ADDED CODE --------
    /// <summary>
    /// Email Service for sending OTP and password reset emails.
    /// Currently simulates email sending for development.
    /// Can be extended to use real SMTP in production.
    /// </summary>
    public class EmailService
    {
        // For production, use real email credentials
        private const string SenderEmail = "railway.system@gmail.com";
        private const string SenderPassword = "your_app_password_here"; // Use App Password for Gmail
        private const string SmtpServer = "smtp.gmail.com";
        private const int SmtpPort = 587;

        /// <summary>
        /// Sends OTP to user's email (Simulated - Prints to console)
        /// In production, replace with real SMTP implementation
        /// </summary>
        public static bool SendOtpEmail(string email, string otp)
        {
            try
            {
                // SIMULATED EMAIL SENDING - For development/testing
                Console.WriteLine($"========== EMAIL SIMULATION ==========");
                Console.WriteLine($"To: {email}");
                Console.WriteLine($"Subject: Your Railway Management System OTP");
                Console.WriteLine($"Body: Your OTP is: {otp}. Valid for 10 minutes.");
                Console.WriteLine($"======================================");

                // Uncomment below for REAL EMAIL SENDING (requires SMTP setup)
                /*
                using (SmtpClient smtpClient = new SmtpClient(SmtpServer, SmtpPort))
                {
                    smtpClient.Credentials = new NetworkCredential(SenderEmail, SenderPassword);
                    smtpClient.EnableSsl = true;

                    MailMessage mailMessage = new MailMessage(SenderEmail, email)
                    {
                        Subject = "Your Railway Management System OTP",
                        Body = $"Your OTP is: {otp}\n\nValid for 10 minutes.",
                        IsBodyHtml = false
                    };

                    smtpClient.Send(mailMessage);
                }
                */

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Email send error: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Sends Password Reset Link/Token to user's email (Simulated)
        /// </summary>
        public static bool SendPasswordResetEmail(string email, string resetToken)
        {
            try
            {
                // SIMULATED EMAIL SENDING
                Console.WriteLine($"========== PASSWORD RESET EMAIL ==========");
                Console.WriteLine($"To: {email}");
                Console.WriteLine($"Subject: Password Reset Request");
                Console.WriteLine($"Body: Your password reset token is: {resetToken}");
                Console.WriteLine($"Use this token to create a new password.");
                Console.WriteLine($"==========================================");

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Email send error: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Sends SMS notification (Simulated)
        /// </summary>
        public static bool SendSmsNotification(string phoneNumber, string message)
        {
            try
            {
                Console.WriteLine($"========== SMS SIMULATION ==========");
                Console.WriteLine($"To: {phoneNumber}");
                Console.WriteLine($"Message: {message}");
                Console.WriteLine($"===================================");

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"SMS send error: {ex.Message}");
                return false;
            }
        }
    }
    // -------- END OF NEWLY ADDED CODE --------
}