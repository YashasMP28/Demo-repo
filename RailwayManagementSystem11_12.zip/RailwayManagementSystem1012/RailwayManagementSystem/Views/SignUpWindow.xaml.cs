﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RailwayManagementSystem.Views
{
    public partial class SignUpWindow : Window
    {
        
        public static readonly DependencyProperty UsernameProperty =
            DependencyProperty.Register(
                "Username",
                typeof(string),
                typeof(SignUpWindow),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnUsernameChanged));

        
        public static readonly DependencyProperty EmailProperty =
            DependencyProperty.Register(
                "Email",
                typeof(string),
                typeof(SignUpWindow),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnEmailChanged));

        
        public static readonly DependencyProperty PasswordProperty =
            DependencyProperty.Register(
                "Password",
                typeof(string),
                typeof(SignUpWindow),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnPasswordChanged));

       
        public static readonly DependencyProperty AddressProperty =
            DependencyProperty.Register(
                "Address",
                typeof(string),
                typeof(SignUpWindow),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnAddressChanged));

        
        public static readonly DependencyProperty PhoneProperty =
            DependencyProperty.Register(
                "Phone",
                typeof(string),
                typeof(SignUpWindow),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnPhoneChanged));

        
        public string Username
        {
            get => (string)GetValue(UsernameProperty);
            set => SetValue(UsernameProperty, value);
        }

        public string Email
        {
            get => (string)GetValue(EmailProperty);
            set => SetValue(EmailProperty, value);
        }

        public string Password
        {
            get => (string)GetValue(PasswordProperty);
            set => SetValue(PasswordProperty, value);
        }

        public string Address
        {
            get => (string)GetValue(AddressProperty);
            set => SetValue(AddressProperty, value);
        }

        public string Phone
        {
            get => (string)GetValue(PhoneProperty);
            set => SetValue(PhoneProperty, value);
        }

        public SignUpWindow()
        {
            InitializeComponent();
        }

        
        private static void OnUsernameChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var window = d as SignUpWindow;
            if (window?.DataContext != null)
            {
                ((dynamic)window.DataContext).Username = e.NewValue as string;
            }
        }

        private static void OnEmailChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var window = d as SignUpWindow;
            if (window?.DataContext != null)
            {
                ((dynamic)window.DataContext).Email = e.NewValue as string;
            }
        }

        private static void OnPasswordChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var window = d as SignUpWindow;
            if (window?.DataContext != null)
            {
                ((dynamic)window.DataContext).Password = e.NewValue as string;
            }
        }

        private static void OnAddressChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var window = d as SignUpWindow;
            if (window?.DataContext != null)
            {
                ((dynamic)window.DataContext).Address = e.NewValue as string;
            }
        }

        private static void OnPhoneChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var window = d as SignUpWindow;
            if (window?.DataContext != null)
            {
                ((dynamic)window.DataContext).Phone = e.NewValue as string;
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (this.DataContext != null)
            {
                ((dynamic)this.DataContext).Password = ((PasswordBox)sender).Password;
                Password = ((PasswordBox)sender).Password;
            }
        }

    }
}