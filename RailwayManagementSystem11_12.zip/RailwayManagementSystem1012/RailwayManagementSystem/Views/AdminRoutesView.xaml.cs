﻿using System.Windows.Controls;

namespace RailwayManagementSystem.Views
{
    public partial class AdminRoutesView : Page
    {
        public AdminRoutesView()
        {
            InitializeComponent();
        }
    }
}