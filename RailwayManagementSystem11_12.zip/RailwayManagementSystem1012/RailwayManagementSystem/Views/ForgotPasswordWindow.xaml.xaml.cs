﻿using RailwayManagementSystem.ViewModels;
using System;
using System.Windows;
using System.Windows.Controls;

namespace RailwayManagementSystem.Views
{
    // -------- NEWLY ADDED CODE --------
    /// <summary>
    /// Interaction logic for ForgotPasswordWindow.xaml
    /// Handles password box password transfer to ViewModel
    /// </summary>
    public partial class ForgotPasswordWindow : Window
    {
        public ForgotPasswordWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles new password box password changed event
        /// Transfers password to ViewModel for validation
        /// </summary>
        private void NewPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is ForgotPasswordViewModel vm)
            {
                vm.NewPassword = NewPasswordBox.Password;
            }
        }

        /// <summary>
        /// Handles confirm password box password changed event
        /// </summary>
        private void ConfirmPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is ForgotPasswordViewModel vm)
            {
                vm.ConfirmPassword = ConfirmPasswordBox.Password;
            }
        }

        /// <summary>
        /// Override OnInitialized to attach password changed handlers
        /// </summary>
        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);

            if (NewPasswordBox != null)
                NewPasswordBox.PasswordChanged += NewPasswordBox_PasswordChanged;

            if (ConfirmPasswordBox != null)
                ConfirmPasswordBox.PasswordChanged += ConfirmPasswordBox_PasswordChanged;
        }
    }
    // -------- END OF NEWLY ADDED CODE --------
}