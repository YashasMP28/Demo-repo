﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;

namespace RailwayManagementSystem.ViewModels
{
    public class AdminTicketsViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private ObservableCollection<Ticket> _tickets;
        private ObservableCollection<string> _sources;
        private ObservableCollection<string> _destinations;

        private string _passengerName;
        private string _trainId;
        private string _selectedSource;
        private string _selectedDestination;
        private DateTime _selectedDate = DateTime.Now;
        private decimal _cost;
        private Ticket _selectedTicket;
        private int _ticketCounter = 1000;

        public AdminTicketsViewModel()
        {
            _dataService = new JsonDataService();

            InitializeStations();
            LoadTickets();

            BookTicketCommand = new RelayCommand(ExecuteBookTicket, CanExecuteBookTicket);
            DeleteTicketCommand = new RelayCommand(ExecuteDeleteTicket, CanExecuteDelete);
        }

        private void InitializeStations()
        {
            Sources = new ObservableCollection<string>
            {
                "Alnavar Junction", "Arsikere", "Badami", "Bagalkot", "Bengaluru","Ballari", "Belagavi", "Birur", "Chikkajajur", "Chitradurga", "Davanagere", "Dharwad",
                "Gadag", "Gangavathi", "Ghataprabha", "Ginigera Junction", "Guntakal", "Harihara", "Hassan", "Hebsur", "Honavar", "Hosapete", "Hospet-AM", "Hotgi",
                "Hubballi Junction", "Kadur", "Karatagi", "Koppal", "Koppala", "Kudachi", "Londa", "Mahabubnagar", "Mandya", "Miraj", "Mysore", "Navalgund", "Raichur",
                "Rayadurg", "Sindhanur", "Tiptur", "Toranagallu", "Tumkur", "Vijayapura", "Yalvigi","Yeshwantpur"
            };

            Destinations = new ObservableCollection<string>(Sources);
        }

        public ObservableCollection<Ticket> Tickets
        {
            get => _tickets;
            set => SetProperty(ref _tickets, value);
        }

        public ObservableCollection<string> Sources
        {
            get => _sources;
            set => SetProperty(ref _sources, value);
        }

        public ObservableCollection<string> Destinations
        {
            get => _destinations;
            set => SetProperty(ref _destinations, value);
        }

        public string PassengerName
        {
            get => _passengerName;
            set => SetProperty(ref _passengerName, value);
        }

        public string TrainId
        {
            get => _trainId;
            set => SetProperty(ref _trainId, value);
        }

        public string SelectedSource
        {
            get => _selectedSource;
            set
            {
                SetProperty(ref _selectedSource, value);
                CalculateCost();
            }
        }

        public string SelectedDestination
        {
            get => _selectedDestination;
            set
            {
                SetProperty(ref _selectedDestination, value);
                CalculateCost();
            }
        }

        public DateTime SelectedDate
        {
            get => _selectedDate;
            set => SetProperty(ref _selectedDate, value);
        }

        public decimal Cost
        {
            get => _cost;
            set => SetProperty(ref _cost, value);
        }
        public Ticket SelectedTicket
        {
            get => _selectedTicket;
            set
            {
                if (SetProperty(ref _selectedTicket, value) && value != null)
                {
                    PassengerName = value.PassengerName;
                    SelectedSource = value.Source;
                    SelectedDestination = value.Destination;
                    SelectedDate = value.Date;
                    Cost = value.Cost;
                }
            }
        }
        public ICommand BookTicketCommand { get; }
        public ICommand DeleteTicketCommand { get; }

        private void LoadTickets()
        {
            try
            {
                var tickets = _dataService.GetAllTickets();
                if (tickets != null)
                {
                    Tickets = new ObservableCollection<Ticket>(tickets);
                }
                else
                {
                    Tickets = new ObservableCollection<Ticket>();
                }
            }
            catch
            {
                Tickets = new ObservableCollection<Ticket>();
            }
        }

        private void CalculateCost()
        {
            if (!string.IsNullOrWhiteSpace(SelectedSource) && !string.IsNullOrWhiteSpace(SelectedDestination))
            {
                int totalChars = SelectedSource.Length + SelectedDestination.Length;
                Cost = 10 * totalChars;
            }
            else
            {
                Cost = 0;
            }
        }
        private bool CanExecuteBookTicket(object parameter)
        {
            return !string.IsNullOrWhiteSpace(PassengerName) &&
                   !string.IsNullOrWhiteSpace(TrainId) &&
                   !string.IsNullOrWhiteSpace(SelectedSource) &&
                   !string.IsNullOrWhiteSpace(SelectedDestination) &&
                   Cost > 0;
        }
        private void ExecuteBookTicket(object parameter)
        {
            var ticket = new Ticket
            {
                TicketId = (++_ticketCounter),
                PassengerName = PassengerName,
                TrainId = TrainId,
                Source = SelectedSource,
                Destination = SelectedDestination,
                Date = SelectedDate,
                Cost = Cost
            };

            Tickets.Add(ticket);
            try
            {
                _dataService.AddTicket(ticket);
            }
            catch
            {
                // Silently continue if service fails
            }

            ClearForm();

            MessageBox.Show("Ticket booked successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool CanExecuteDelete(object parameter)
        {
            return SelectedTicket != null;
        }

        private void ExecuteDeleteTicket(object parameter)
        {
            var result = MessageBox.Show(
                "Are you sure you want to delete this ticket?",
                "Confirm Delete",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes && SelectedTicket != null)
            {
                int ticketIdToDelete = SelectedTicket.TicketId; // store before removing

                Tickets.Remove(SelectedTicket);

                try
                {
                    _dataService.DeleteTicket(ticketIdToDelete);
                }
                catch
                {
                    // Silently continue if service fails
                }

                ClearForm();

                MessageBox.Show("Ticket deleted successfully!", "Success",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void ClearForm()
        {
            PassengerName = string.Empty;
            TrainId = string.Empty;
            SelectedSource = null;
            SelectedDestination = null;
            SelectedDate = DateTime.Now;
            Cost = 0;
            SelectedTicket = null;
        }
    }
}