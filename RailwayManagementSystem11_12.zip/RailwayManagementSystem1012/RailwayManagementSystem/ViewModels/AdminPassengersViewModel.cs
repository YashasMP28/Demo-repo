﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;

namespace RailwayManagementSystem.ViewModels
{
    public class AdminPassengersViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private ObservableCollection<Passenger> _passengers;
        private Passenger _selectedPassenger;

        private string _username;
        private string _email;
        private string _password;
        private string _address;
        private string _phone;
        private string _gender = "Male";

        public AdminPassengersViewModel()
        {
            _dataService = new JsonDataService();
            LoadPassengers();

            AddPassengerCommand = new RelayCommand(ExecuteAddPassenger, CanExecuteAdd);
            UpdatePassengerCommand = new RelayCommand(ExecuteUpdatePassenger, CanExecuteUpdate);
            DeletePassengerCommand = new RelayCommand(ExecuteDeletePassenger, CanExecuteUpdate);
        }

        public ObservableCollection<Passenger> Passengers
        {
            get => _passengers;
            set => SetProperty(ref _passengers, value);
        }

        public Passenger SelectedPassenger
        {
            get => _selectedPassenger;
            set
            {
                if (SetProperty(ref _selectedPassenger, value) && value != null)
                {
                    Username = value.Username;
                    Email = value.Email;
                    Password = value.Password;
                    Address = value.Address;
                    Phone = value.Phone;
                    Gender = value.Gender;
                }
            }
        }

        public string Username
        {
            get => _username;
            set => SetProperty(ref _username, value);
        }

        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value);
        }

        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }

        public string Address
        {
            get => _address;
            set => SetProperty(ref _address, value);
        }

        public string Phone
        {
            get => _phone;
            set => SetProperty(ref _phone, value);
        }

        public string Gender
        {
            get => _gender;
            set => SetProperty(ref _gender, value);
        }

        public ICommand AddPassengerCommand { get; }
        public ICommand UpdatePassengerCommand { get; }
        public ICommand DeletePassengerCommand { get; }

        private void LoadPassengers()
        {
            Passengers = new ObservableCollection<Passenger>(_dataService.GetAllPassengers());
        }

        private bool CanExecuteAdd(object parameter)
        {
            return !string.IsNullOrWhiteSpace(Username) &&
                   !string.IsNullOrWhiteSpace(Email) &&
                   !string.IsNullOrWhiteSpace(Password) &&
                   !string.IsNullOrWhiteSpace(Address) &&
                   !string.IsNullOrWhiteSpace(Phone);
        }

        private void ExecuteAddPassenger(object parameter)
        {
            var passenger = new Passenger
            {
                Username = Username,
                Email = Email,
                Password = Password,
                Address = Address,
                Phone = Phone,
                Gender = Gender
            };

            _dataService.AddPassenger(passenger);
            LoadPassengers();
            ClearForm();

            MessageBox.Show("Passenger added successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool CanExecuteUpdate(object parameter)
        {
            return SelectedPassenger != null;
        }

        private void ExecuteUpdatePassenger(object parameter)
        {
            SelectedPassenger.Username = Username;
            SelectedPassenger.Email = Email;
            SelectedPassenger.Password = Password;
            SelectedPassenger.Address = Address;
            SelectedPassenger.Phone = Phone;
            SelectedPassenger.Gender = Gender;

            _dataService.UpdatePassenger(SelectedPassenger);
            LoadPassengers();
            ClearForm();

            MessageBox.Show("Passenger updated successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ExecuteDeletePassenger(object parameter)
        {
            var result = MessageBox.Show(
                "Are you sure you want to delete this passenger?",
                "Confirm Delete",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                _dataService.DeletePassenger(SelectedPassenger.Id);
                LoadPassengers();
                ClearForm();

                MessageBox.Show("Passenger deleted successfully!", "Success",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ClearForm()
        {
            Username = string.Empty;
            Email = string.Empty;
            Password = string.Empty;
            Address = string.Empty;
            Phone = string.Empty;
            Gender = "Male";
            SelectedPassenger = null;
        }
    }
}