﻿using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Services;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace RailwayManagementSystem.ViewModels
{
    // -------- NEWLY ADDED CODE --------
    /// <summary>
    /// ViewModel for OTP Login functionality
    /// Handles OTP generation, sending, and validation for email-based login
    /// </summary>
    public class OtpLoginViewModel : INotifyPropertyChanged
    {
        private string _email;
        private string _otp;
        private string _statusMessage;
        private string _currentStep = "email"; // email, otp
        private bool _isOtpGenerated;
        private int _otpResendCountdown;

        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }

        public string Otp
        {
            get => _otp;
            set { _otp = value; OnPropertyChanged(); }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set { _statusMessage = value; OnPropertyChanged(); }
        }

        public string CurrentStep
        {
            get => _currentStep;
            set { _currentStep = value; OnPropertyChanged(); }
        }

        public bool IsOtpGenerated
        {
            get => _isOtpGenerated;
            set { _isOtpGenerated = value; OnPropertyChanged(); }
        }

        public int OtpResendCountdown
        {
            get => _otpResendCountdown;
            set { _otpResendCountdown = value; OnPropertyChanged(); }
        }

        public ICommand GenerateOtpCommand { get; }
        public ICommand ValidateOtpCommand { get; }
        public ICommand ResendOtpCommand { get; }
        public ICommand BackCommand { get; }
        public ICommand CancelCommand { get; }

        public OtpLoginViewModel()
        {
            GenerateOtpCommand = new RelayCommand(ExecuteGenerateOtp, o => CanGenerateOtp());
            ValidateOtpCommand = new RelayCommand(ExecuteValidateOtp, o => CanValidateOtp());
            ResendOtpCommand = new RelayCommand(ExecuteResendOtp);
            BackCommand = new RelayCommand(ExecuteBack);
            CancelCommand = new RelayCommand(ExecuteCancel);
        }

        /// <summary>
        /// Validates if OTP can be generated
        /// </summary>
        private bool CanGenerateOtp()
        {
            return !string.IsNullOrWhiteSpace(Email) && Email.Contains("@");
        }

        /// <summary>
        /// Validates if OTP can be submitted
        /// </summary>
        private bool CanValidateOtp()
        {
            return !string.IsNullOrWhiteSpace(Otp) && Otp.Length == 6;
        }

        /// <summary>
        /// Generates OTP and sends it to user's email
        /// </summary>
        private void ExecuteGenerateOtp(object parameter)
        {
            try
            {
                StatusMessage = "Generating OTP...";

                
                var dataService = new JsonDataService();
                var user = dataService.GetUserByEmail(Email);

                if (user == null)
                {
                    StatusMessage = "Email not registered with us.";
                    return;
                }

                // Generate OTP
                string generatedOtp = OtpService.GenerateOtp(Email);

                if (generatedOtp == null)
                {
                    StatusMessage = "Failed to generate OTP. Please try again.";
                    return;
                }

                // Send OTP to email
                bool emailSent = EmailService.SendOtpEmail(Email, generatedOtp);

                if (emailSent)
                {
                    IsOtpGenerated = true;
                    CurrentStep = "otp";
                    StatusMessage = $"OTP has been sent to {Email}. Valid for 10 minutes.";
                    OtpResendCountdown = 60; // 60 seconds before resend is allowed
                    StartResendCountdown();
                }
                else
                {
                    StatusMessage = "Failed to send OTP. Please try again.";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error: {ex.Message}";
                Console.WriteLine($"OTP generation error: {ex.Message}");
            }
        }

        /// <summary>
        /// Validates the OTP and logs in the user
        /// </summary>
        private void ExecuteValidateOtp(object parameter)
        {
            try
            {
                StatusMessage = "Validating OTP...";

                // Validate OTP
                bool isValid = OtpService.ValidateOtp(Email, Otp);

                if (isValid)
                {
                    var dataService = new JsonDataService();
                    var user = dataService.GetUserByEmail(Email);
                    AuthenticationService.CurrentUser = user;

                    StatusMessage = "Login successful!";
                    MessageBox.Show("Login successful!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                    // Navigate to MainWindow
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var mainWindow = new MainWindow();
                        mainWindow.Show();

                        // Close OTP Login Window
                        var window = parameter as Window;
                        window?.Close();

                        // Close Login Window if open
                        foreach (Window w in Application.Current.Windows)
                        {
                            if (w is LoginWindow)
                            {
                                w.Close();
                                break;
                            }
                        }
                    });
                }
                else
                {
                    StatusMessage = "Invalid OTP. Please check and try again.";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error: {ex.Message}";
                Console.WriteLine($"OTP validation error: {ex.Message}");
            }
        }

        /// <summary>
        /// Resends OTP to the same email
        /// </summary>
        private void ExecuteResendOtp(object parameter)
        {
            try
            {
                if (OtpResendCountdown > 0)
                {
                    StatusMessage = $"Please wait {OtpResendCountdown} seconds before resending.";
                    return;
                }

                StatusMessage = "Resending OTP...";

                string newOtp = OtpService.ResendOtp(Email);

                if (newOtp != null)
                {
                    EmailService.SendOtpEmail(Email, newOtp);
                    StatusMessage = "OTP resent successfully!";
                    Otp = string.Empty;
                    OtpResendCountdown = 60;
                    StartResendCountdown();
                }
                else
                {
                    StatusMessage = "Failed to resend OTP.";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error: {ex.Message}";
            }
        }

        /// <summary>
        /// Starts countdown timer for resend button
        /// </summary>
        private void StartResendCountdown()
        {
            var timer = new System.Timers.Timer(1000);
            timer.Elapsed += (s, e) =>
            {
                OtpResendCountdown--;
                if (OtpResendCountdown <= 0)
                {
                    timer.Stop();
                    timer.Dispose();
                }
            };
            timer.Start();
        }

        /// <summary>
        /// Goes back to email entry step
        /// </summary>
        private void ExecuteBack(object parameter)
        {
            CurrentStep = "email";
            IsOtpGenerated = false;
            Otp = string.Empty;
            StatusMessage = string.Empty;
        }

        /// <summary>
        /// Closes the OTP login window
        /// </summary>
        private void ExecuteCancel(object parameter)
        {
            var window = parameter as Window;
            window?.Close();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = "") =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
    // -------- END OF NEWLY ADDED CODE --------
}