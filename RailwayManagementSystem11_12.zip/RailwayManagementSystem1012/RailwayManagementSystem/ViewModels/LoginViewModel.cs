﻿using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Services;
using RailwayManagementSystem.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace RailwayManagementSystem.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private string _email;
        private string _password;
        private string _errorMessage;

        public string Email
        {
            get => _email;
            set
            {
                _email = value; OnPropertyChanged();
                ValidateEmail();
            }
        }

        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        public RelayCommand LoginCommand { get; }
        public RelayCommand ExitCommand { get; }
        public RelayCommand SignUpCommand { get; }

        // -------- NEWLY ADDED CODE --------
        public RelayCommand ForgotPasswordCommand { get; }
        public RelayCommand OtpLoginCommand { get; }
        // -------- END OF NEWLY ADDED CODE --------

        public LoginViewModel()
        {
            LoginCommand = new RelayCommand(o => ExecuteLogin());
            ExitCommand = new RelayCommand(o => ExecuteExit());
            SignUpCommand = new RelayCommand(o => ExecuteSignUp());

            // -------- NEWLY ADDED CODE --------
            ForgotPasswordCommand = new RelayCommand(o => ExecuteForgotPassword());
            OtpLoginCommand = new RelayCommand(o => ExecuteOtpLogin());
            // -------- END OF NEWLY ADDED CODE --------
        }

        private void ExecuteLogin()
        {
            var user = AuthenticationService.Login(Email, Password);

            if (user == null)
            {
                ErrorMessage = "Invalid email or password.";
                return;
            }

            AuthenticationService.CurrentUser = user;

            Application.Current.Dispatcher.Invoke(() =>
            {
                var window = new MainWindow();
                window.Show();
                foreach (Window w in Application.Current.Windows)
                {
                    if (w is LoginWindow)
                    {
                        w.Close();
                        break;
                    }
                }
            });
        }

        private void ExecuteExit()
        {
            Application.Current.Shutdown();
        }

        private void ExecuteSignUp()
        {
            var signUpWindow = new SignUpWindow();
            signUpWindow.Show();
            CloseLoginWindow();
        }

        private void ValidateEmail()
        {
            if (!IsValidEmail(Email))
            {
                ErrorMessage = "Please enter a valid Gmail address (example@gmail.com)";
            }
            else
            {
                ErrorMessage = string.Empty;
            }
        }

        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            var gmailPattern = @"^[a-zA-Z0-9._%+-]+@gmail\.com$";
            return Regex.IsMatch(email, gmailPattern);
        }

        private void CloseLoginWindow()
        {
            foreach (Window w in Application.Current.Windows)
                if (w is LoginWindow) { w.Close(); break; }
        }

        // -------- NEWLY ADDED CODE --------
        /// <summary>
        /// Opens Forgot Password window for password reset
        /// </summary>
        private void ExecuteForgotPassword()
        {
            var forgotPasswordWindow = new ForgotPasswordWindow();
            forgotPasswordWindow.Show();
            CloseLoginWindow();
        }

        /// <summary>
        /// Opens OTP Login window for OTP-based authentication
        /// </summary>
        private void ExecuteOtpLogin()
        {
            var otpLoginWindow = new OtpLoginWindow();
            otpLoginWindow.Show();
            CloseLoginWindow();
        }
        // -------- END OF NEWLY ADDED CODE --------

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = "") =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}