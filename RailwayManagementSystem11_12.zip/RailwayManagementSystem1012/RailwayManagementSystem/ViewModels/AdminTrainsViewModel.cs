﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;

namespace RailwayManagementSystem.ViewModels
{
    public class AdminTrainsViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private ObservableCollection<Train> _trains;
        private ObservableCollection<string> _operationalStatusOptions;

        private string _trainId;
        private string _trainName;
        private string _totalSeats = " ";
        private string _operationalStatus = "Active";
        private Train _selectedTrain;
        private string _errorMessage = "";

        public AdminTrainsViewModel()
        {
            _dataService = new JsonDataService();

            InitializeOperationalStatus();
            LoadTrains();

            AddTrainCommand = new RelayCommand(ExecuteAddTrain, CanExecuteAdd);
            UpdateTrainCommand = new RelayCommand(ExecuteUpdateTrain, CanExecuteUpdate);
            DeleteTrainCommand = new RelayCommand(ExecuteDeleteTrain, CanExecuteUpdate);
        }

        private void InitializeOperationalStatus()
        {
            OperationalStatusOptions = new ObservableCollection<string> { "Active", "Inactive", "Maintenance" };
        }

        public ObservableCollection<Train> Trains
        {
            get => _trains;
            set => SetProperty(ref _trains, value);
        }

        public ObservableCollection<string> OperationalStatusOptions
        {
            get => _operationalStatusOptions;
            set => SetProperty(ref _operationalStatusOptions, value);
        }

        public string TrainId
        {
            get => _trainId;
            set => SetProperty(ref _trainId, value);
        }

        public string TrainName
        {
            get => _trainName;
            set => SetProperty(ref _trainName, value);
        }

        public string TotalSeats
        {
            get => _totalSeats;
            set
            {
                if (SetProperty(ref _totalSeats, value))
                {
                    ValidateTotalSeats();
                }
            }
        }
        public string OperationalStatus
        {
            get => _operationalStatus;
            set => SetProperty(ref _operationalStatus, value);
        }
        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }
        public Train SelectedTrain
        {
            get => _selectedTrain;
            set
            {
                if (SetProperty(ref _selectedTrain, value) && value != null)
                {
                    TrainId = value.TrainId.ToString();
                    TrainName = value.TrainName;
                    TotalSeats = value.TotalSeats.ToString();
                    OperationalStatus = value.OperationalStatus;
                    ErrorMessage = "";
                }
            }
        }
        public ICommand AddTrainCommand { get; }
        public ICommand UpdateTrainCommand { get; }
        public ICommand DeleteTrainCommand { get; }
        private void ValidateTotalSeats()
        {
            if (string.IsNullOrWhiteSpace(TotalSeats))
            {
                ErrorMessage = "Total Seats cannot be empty";
            }
            else if (!int.TryParse(TotalSeats, out int seats))
            {
                ErrorMessage = "Total Seats must be a valid number";
            }
            else if (seats <= 0)
            {
                ErrorMessage = "Total Seats must be greater than 0";
            }
            else
            {
                ErrorMessage = "";
            }
        }
        private void LoadTrains()
        {
            try
            {
                var trains = _dataService.GetAllTrains();
                if (trains != null)
                {
                    Trains = new ObservableCollection<Train>(trains);
                }
                else
                {
                    Trains = new ObservableCollection<Train>
                    {
                        new Train { TrainId = 1001, TrainName = "Express 101", TotalSeats = 120, OperationalStatus = "Active" },
                        new Train { TrainId = 1002, TrainName = "Rapid 202", TotalSeats = 150, OperationalStatus = "Active" },
                        new Train { TrainId = 1003, TrainName = "Local 303", TotalSeats = 100, OperationalStatus = "Active" }
                    };
                }
            }
            catch
            {
                Trains = new ObservableCollection<Train>
                {
                    new Train { TrainId = 1001, TrainName = "Express 101", TotalSeats = 120, OperationalStatus = "Active" },
                    new Train { TrainId = 1002, TrainName = "Rapid 202", TotalSeats = 150, OperationalStatus = "Active" },
                    new Train { TrainId = 1003, TrainName = "Local 303", TotalSeats = 100, OperationalStatus = "Active" }
                };
            }
        }

        private bool CanExecuteAdd(object parameter)
        {
            return !string.IsNullOrWhiteSpace(TrainId) &&
                   !string.IsNullOrWhiteSpace(TrainName) &&
                   int.TryParse(TotalSeats, out int seats) &&
                   seats > 0 &&
                   string.IsNullOrEmpty(ErrorMessage);
        }

        private void ExecuteAddTrain(object parameter)
        {
            if (!int.TryParse(TrainId, out int trainId))
            {
                ErrorMessage = "Train ID must be a number";
                return;
            }
            if (!int.TryParse(TotalSeats, out int totalSeats))
            {
                ErrorMessage = "Total Seats must be a number";
                return;
            }
            if (totalSeats <= 0)
            {
                ErrorMessage = "Total Seats must be greater than 0";
                return;
            }
            var train = new Train
            {
                TrainId = trainId,
                TrainName = TrainName,
                TotalSeats = totalSeats,
                OperationalStatus = OperationalStatus
            };
            _dataService.AddTrain(train);
            LoadTrains();
            ClearForm();
            MessageBox.Show("Train added successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private bool CanExecuteUpdate(object parameter)
        {
            return SelectedTrain != null;
        }

        private void ExecuteUpdateTrain(object parameter)
        {
            if (!int.TryParse(TrainId, out int trainId))
            {
                ErrorMessage = "Train ID must be a number";
                return;
            }

            if (!int.TryParse(TotalSeats, out int totalSeats))
            {
                ErrorMessage = "Total Seats must be a number";
                return;
            }

            if (totalSeats <= 0)
            {
                ErrorMessage = "Total Seats must be greater than 0";
                return;
            }

            SelectedTrain.TrainId = trainId;
            SelectedTrain.TrainName = TrainName;
            SelectedTrain.TotalSeats = totalSeats;
            SelectedTrain.OperationalStatus = OperationalStatus;

            _dataService.UpdateTrain(SelectedTrain);
            LoadTrains();
            ClearForm();

            MessageBox.Show("Train updated successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ExecuteDeleteTrain(object parameter)
        {
            var result = MessageBox.Show(
                "Are you sure you want to delete this train?",
                "Confirm Delete",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                _dataService.DeleteTrain(SelectedTrain.TrainId);
                LoadTrains();
                ClearForm();

                MessageBox.Show("Train deleted successfully!", "Success",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ClearForm()
        {
            TrainId = string.Empty;
            TrainName = string.Empty;
            TotalSeats = "";
            OperationalStatus = "Active";
            SelectedTrain = null;
            ErrorMessage = "";
        }
    }
}