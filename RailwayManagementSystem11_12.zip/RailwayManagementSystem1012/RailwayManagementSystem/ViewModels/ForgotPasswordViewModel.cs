﻿using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Services;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace RailwayManagementSystem.ViewModels
{
    // -------- NEWLY ADDED CODE --------
    /// <summary>
    /// ViewModel for Forgot Password functionality
    /// Handles email verification, token generation, and password reset
    /// </summary>
    public class ForgotPasswordViewModel : INotifyPropertyChanged
    {
        private readonly PasswordResetService _resetService;
        private string _email;
        private string _phoneNumber;
        private string _resetToken;
        private string _newPassword;
        private string _confirmPassword;
        private string _statusMessage;
        private string _currentStep = "verification"; // verification, reset
        private bool _isResettingPassword;

        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }

        public string PhoneNumber
        {
            get => _phoneNumber;
            set { _phoneNumber = value; OnPropertyChanged(); }
        }

        public string ResetToken
        {
            get => _resetToken;
            set { _resetToken = value; OnPropertyChanged(); }
        }

        public string NewPassword
        {
            get => _newPassword;
            set { _newPassword = value; OnPropertyChanged(); }
        }

        public string ConfirmPassword
        {
            get => _confirmPassword;
            set { _confirmPassword = value; OnPropertyChanged(); }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set { _statusMessage = value; OnPropertyChanged(); }
        }

        public string CurrentStep
        {
            get => _currentStep;
            set { _currentStep = value; OnPropertyChanged(); }
        }

        public bool IsResettingPassword
        {
            get => _isResettingPassword;
            set { _isResettingPassword = value; OnPropertyChanged(); }
        }

        public ICommand VerifyCommand { get; }
        public ICommand ResetPasswordCommand { get; }
        public ICommand BackCommand { get; }
        public ICommand CancelCommand { get; }

        public ForgotPasswordViewModel()
        {
            _resetService = new PasswordResetService();

            VerifyCommand = new RelayCommand(ExecuteVerify, o => CanVerify());
            ResetPasswordCommand = new RelayCommand(ExecuteResetPassword, o => CanResetPassword());
            BackCommand = new RelayCommand(ExecuteBack);
            CancelCommand = new RelayCommand(ExecuteCancel);
        }

        /// <summary>
        /// Validates if verification fields can be executed
        /// </summary>
        private bool CanVerify()
        {
            return !string.IsNullOrWhiteSpace(Email) && !string.IsNullOrWhiteSpace(PhoneNumber);
        }

        /// <summary>
        /// Validates if password reset can be executed
        /// </summary>
        private bool CanResetPassword()
        {
            return !string.IsNullOrWhiteSpace(NewPassword) &&
                   !string.IsNullOrWhiteSpace(ConfirmPassword) &&
                   NewPassword.Length >= 6;
        }

        /// <summary>
        /// Executes verification of email and phone number
        /// </summary>
        private void ExecuteVerify(object parameter)
        {
            try
            {
                StatusMessage = "Verifying...";

                // Initiate password reset (which verifies email and phone)
                var result = _resetService.InitiatePasswordReset(Email, PhoneNumber);

                if (result.Success)
                {
                    ResetToken = result.ResetToken;
                    StatusMessage = result.Message;

                    // Send email notification
                    EmailService.SendPasswordResetEmail(Email, ResetToken);

                    // Move to password reset step
                    IsResettingPassword = true;
                    CurrentStep = "reset";
                }
                else
                {
                    StatusMessage = $"Verification Failed: {result.Message}";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error: {ex.Message}";
                Console.WriteLine($"Verification error: {ex.Message}");
            }
        }

        /// <summary>
        /// Executes password reset
        /// </summary>
        private void ExecuteResetPassword(object parameter)
        {
            try
            {
                StatusMessage = "Resetting password...";

                var result = _resetService.ResetPassword(ResetToken, NewPassword, ConfirmPassword);

                if (result.Success)
                {
                    StatusMessage = result.Message;

                    MessageBox.Show(result.Message, "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                    // Close the window
                    var window = parameter as Window;
                    window?.Close();
                }
                else
                {
                    StatusMessage = $"Reset Failed: {result.Message}";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error: {ex.Message}";
                Console.WriteLine($"Password reset error: {ex.Message}");
            }
        }

        /// <summary>
        /// Goes back to verification step
        /// </summary>
        private void ExecuteBack(object parameter)
        {
            CurrentStep = "verification";
            IsResettingPassword = false;
            NewPassword = string.Empty;
            ConfirmPassword = string.Empty;
            StatusMessage = string.Empty;
        }

        /// <summary>
        /// Closes the forgot password window
        /// </summary>
        private void ExecuteCancel(object parameter)
        {
            var window = parameter as Window;
            window?.Close();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = "") =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
    // -------- END OF NEWLY ADDED CODE --------
}