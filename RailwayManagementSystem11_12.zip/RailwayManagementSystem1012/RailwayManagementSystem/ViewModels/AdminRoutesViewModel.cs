﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;

namespace RailwayManagementSystem.ViewModels
{
    public class AdminRoutesViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private ObservableCollection<Route> _routes;
        private ObservableCollection<Train> _trains;
        private ObservableCollection<string> _sources;
        private ObservableCollection<string> _destinations;

        private string _selectedSource;
        private string _selectedDestination;
        private int? _selectedTrainId;
        private DateTime _selectedDate = DateTime.Now;
        private string _cost = " ";
        private Route _selectedRoute;
        private string _costErrorMessage = "";

        public AdminRoutesViewModel()
        {
            _dataService = new JsonDataService();

            InitializeStations();
            InitializeTrainIdDropdown();
            LoadData();

            AddRouteCommand = new RelayCommand(ExecuteAddRoute, CanExecuteAddRoute);
            UpdateRouteCommand = new RelayCommand(ExecuteUpdateRoute, CanExecuteUpdate);
            DeleteRouteCommand = new RelayCommand(ExecuteDeleteRoute, CanExecuteUpdate);
        }

        private void InitializeStations()
        {
            Sources = new ObservableCollection<string>
            {
                "Alnavar Junction", "Arsikere", "Badami", "Bagalkot", "Ballari", "Belagavi", "Birur", "Chikkajajur", "Chitradurga", "Davanagere", "Dharwad",
                "Gadag", "Gangavathi", "Ghataprabha", "Ginigera Junction", "Guntakal", "Harihara", "Hassan", "Hebsur", "Honavar", "Hosapete", "Hospet-AM", "Hotgi",
                "Hubballi Junction", "Kadur", "Karatagi", "Koppal", "Koppala", "Kudachi", "Londa", "Mahabubnagar", "Mandya", "Miraj", "Mysore", "Navalgund", "Raichur",
                "Rayadurg", "Sindhanur", "Tiptur", "Toranagallu", "Tumkur", "Vijayapura", "Yalvigi"
            };

            Destinations = new ObservableCollection<string>(Sources);
        }

        private void InitializeTrainIdDropdown()
        {
            var trainIds = new ObservableCollection<Train>();
            for (int i = 10001; i <= 10050; i++)
            {
                trainIds.Add(new Train
                {
                    TrainId = i,
                    TrainName = $"Train {i}",
                    TotalSeats = 100,
                    OperationalStatus = "Active"
                });
            }
            Trains = trainIds;
        }

        public ObservableCollection<Route> Routes
        {
            get => _routes;
            set => SetProperty(ref _routes, value);
        }

        public ObservableCollection<Train> Trains
        {
            get => _trains;
            set => SetProperty(ref _trains, value);
        }

        public ObservableCollection<string> Sources
        {
            get => _sources;
            set => SetProperty(ref _sources, value);
        }

        public ObservableCollection<string> Destinations
        {
            get => _destinations;
            set => SetProperty(ref _destinations, value);
        }

        public string SelectedSource
        {
            get => _selectedSource;
            set => SetProperty(ref _selectedSource, value);
        }

        public string SelectedDestination
        {
            get => _selectedDestination;
            set => SetProperty(ref _selectedDestination, value);
        }

        public int? SelectedTrainId
        {
            get => _selectedTrainId;
            set => SetProperty(ref _selectedTrainId, value);
        }

        public DateTime SelectedDate
        {
            get => _selectedDate;
            set => SetProperty(ref _selectedDate, value);
        }

        public string Cost
        {
            get => _cost;
            set
            {
                if (SetProperty(ref _cost, value))
                {
                    ValidateCost();
                }
            }
        }

        public string CostErrorMessage
        {
            get => _costErrorMessage;
            set => SetProperty(ref _costErrorMessage, value);
        }

        public Route SelectedRoute
        {
            get => _selectedRoute;
            set
            {
                if (SetProperty(ref _selectedRoute, value) && value != null)
                {
                    SelectedSource = value.Source;
                    SelectedDestination = value.Destination;
                    SelectedTrainId = value.TrainId;
                    SelectedDate = value.Date;
                    Cost = value.Cost.ToString("F2");
                    CostErrorMessage = "";
                }
            }
        }

        public ICommand AddRouteCommand { get; }
        public ICommand UpdateRouteCommand { get; }
        public ICommand DeleteRouteCommand { get; }

        private void ValidateCost()
        {
            if (string.IsNullOrWhiteSpace(Cost))
            {
                CostErrorMessage = "Cost cannot be empty";
            }
            else if (!decimal.TryParse(Cost, out decimal costValue))
            {
                CostErrorMessage = "Cost must be a valid number";
            }
            else if (costValue <= 0)
            {
                CostErrorMessage = "Cost must be greater than 0";
            }
            else
            {
                CostErrorMessage = "";
            }
        }

        private void LoadData()
        {
            try
            {
                var routes = _dataService.GetAllRoutes();
                Routes = new ObservableCollection<Route>(routes ?? new System.Collections.Generic.List<Route>());
            }
            catch
            {
                Routes = new ObservableCollection<Route>();
            }
        }

        private bool CanExecuteAddRoute(object parameter)
        {
            return !string.IsNullOrWhiteSpace(SelectedSource) &&
                   !string.IsNullOrWhiteSpace(SelectedDestination) &&
                   SelectedTrainId.HasValue &&
                   decimal.TryParse(Cost, out decimal cost) &&
                   cost > 0 &&
                   string.IsNullOrEmpty(CostErrorMessage);
        }

        private void ExecuteAddRoute(object parameter)
        {
            var train = Trains.FirstOrDefault(t => t.TrainId == SelectedTrainId.Value);
            if (train == null)
            {
                MessageBox.Show("Please select a valid train.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!decimal.TryParse(Cost, out decimal costValue))
            {
                CostErrorMessage = "Cost must be a valid number";
                return;
            }

            if (costValue <= 0)
            {
                CostErrorMessage = "Cost must be greater than 0";
                return;
            }

            var route = new Route
            {
                Source = SelectedSource,
                Destination = SelectedDestination,
                TrainId = SelectedTrainId.Value,
                TrainName = train.TrainName,
                Date = SelectedDate,
                Cost = costValue
            };

            _dataService.AddRoute(route);
            LoadData();
            ClearForm();

            MessageBox.Show("Route added successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool CanExecuteUpdate(object parameter)
        {
            return SelectedRoute != null;
        }

        private void ExecuteUpdateRoute(object parameter)
        {
            var train = Trains.FirstOrDefault(t => t.TrainId == SelectedTrainId.Value);
            if (train == null)
            {
                MessageBox.Show("Please select a valid train.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!decimal.TryParse(Cost, out decimal costValue))
            {
                CostErrorMessage = "Cost must be a valid number";
                return;
            }

            if (costValue <= 0)
            {
                CostErrorMessage = "Cost must be greater than 0";
                return;
            }

            SelectedRoute.Source = SelectedSource;
            SelectedRoute.Destination = SelectedDestination;
            SelectedRoute.TrainId = SelectedTrainId.Value;
            SelectedRoute.TrainName = train.TrainName;
            SelectedRoute.Date = SelectedDate;
            SelectedRoute.Cost = costValue;

            _dataService.UpdateRoute(SelectedRoute);
            LoadData();
            ClearForm();

            MessageBox.Show("Route updated successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ExecuteDeleteRoute(object parameter)
        {
            var result = MessageBox.Show(
                "Are you sure you want to delete this route?",
                "Confirm Delete",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                _dataService.DeleteRoute(SelectedRoute.Id);
                LoadData();
                ClearForm();

                MessageBox.Show("Route deleted successfully!", "Success",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ClearForm()
        {
            SelectedSource = null;
            SelectedDestination = null;
            SelectedTrainId = null;
            SelectedDate = DateTime.Now;
            Cost = " ";
            SelectedRoute = null;
            CostErrorMessage = "";
        }
    }
}