﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Input;
using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;

namespace RailwayManagementSystem.ViewModels
{
    public class SearchRoutesViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private ObservableCollection<Route> _routes;
        private ObservableCollection<Route> _filteredRoutes;
        private string _selectedSearchBy;
        private string _searchText;
        private Route _selectedRoute;

        public SearchRoutesViewModel()
        {
            _dataService = new JsonDataService();

            SearchByOptions = new ObservableCollection<string>
            {
                "Source", "Destination", "Cost", "Train", "Date"
            };

            LoadRoutes();

            SearchCommand = new RelayCommand(ExecuteSearch);
        }

        public ObservableCollection<string> SearchByOptions { get; }

        public ObservableCollection<Route> Routes
        {
            get => _routes;
            set => SetProperty(ref _routes, value);
        }

        public ObservableCollection<Route> FilteredRoutes
        {
            get => _filteredRoutes;
            set => SetProperty(ref _filteredRoutes, value);
        }

        public string SelectedSearchBy
        {
            get => _selectedSearchBy;
            set => SetProperty(ref _selectedSearchBy, value);
        }

        public string SearchText
        {
            get => _searchText;
            set => SetProperty(ref _searchText, value);
        }

        public Route SelectedRoute
        {
            get => _selectedRoute;
            set => SetProperty(ref _selectedRoute, value);
        }

        public ICommand SearchCommand { get; }

        private void LoadRoutes()
        {
            var allRoutes = _dataService.GetAllRoutes();
            Routes = new ObservableCollection<Route>(allRoutes);
            FilteredRoutes = new ObservableCollection<Route>(allRoutes);
        }

        private void ExecuteSearch(object parameter)
        {
            if (string.IsNullOrWhiteSpace(SearchText) || string.IsNullOrWhiteSpace(SelectedSearchBy))
            {
                FilteredRoutes = new ObservableCollection<Route>(Routes);
                return;
            }

            var filtered = Routes.Where(r =>
            {
                if (SelectedSearchBy == "Source")
                    return r.Source.IndexOf(SearchText, StringComparison.OrdinalIgnoreCase) >= 0;
                else if (SelectedSearchBy == "Destination")
                    return r.Destination.IndexOf(SearchText, StringComparison.OrdinalIgnoreCase) >= 0;
                else if (SelectedSearchBy == "Cost")
                    return r.Cost.ToString().Contains(SearchText);
                else if (SelectedSearchBy == "Train")
                    return r.TrainName.IndexOf(SearchText, StringComparison.OrdinalIgnoreCase) >= 0;
                else if (SelectedSearchBy == "Date")
                    return r.Date.ToString("d").Contains(SearchText);
                else
                    return true;
                
                    //return SelectedSearchBy switch
                    //{
                    //    "Source" => r.Source.Contains(SearchText, StringComparison.OrdinalIgnoreCase),
                    //    "Destination" => r.Destination.Contains(SearchText, StringComparison.OrdinalIgnoreCase),

                    //};
            }).ToList();

            FilteredRoutes = new ObservableCollection<Route>(filtered);
        }
    }
}
