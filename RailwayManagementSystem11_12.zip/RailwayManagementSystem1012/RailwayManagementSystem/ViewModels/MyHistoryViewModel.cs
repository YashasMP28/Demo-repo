﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;

namespace RailwayManagementSystem.ViewModels
{
    public class MyHistoryViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private ObservableCollection<Ticket> _tickets;
        private Ticket _selectedTicket;

        public MyHistoryViewModel()
        {
            _dataService = new JsonDataService();
            LoadTickets();

            CancelTicketCommand = new RelayCommand(ExecuteCancelTicket, CanExecuteCancelTicket);
            RefreshCommand = new RelayCommand(ExecuteRefresh);
        }

        public ObservableCollection<Ticket> Tickets
        {
            get => _tickets;
            set => SetProperty(ref _tickets, value);
        }

        public Ticket SelectedTicket
        {
            get => _selectedTicket;
            set => SetProperty(ref _selectedTicket, value);
        }

        public ICommand CancelTicketCommand { get; }
        public ICommand RefreshCommand { get; }

        private void LoadTickets()
        {
            if (AuthenticationService.CurrentUser != null)
            {
                var userTickets = _dataService.GetTicketsByUserId(AuthenticationService.CurrentUser.Id);
                Tickets = new ObservableCollection<Ticket>(userTickets.OrderByDescending(t => t.BookingDate));
            }
        }

        private bool CanExecuteCancelTicket(object parameter)
        {
            return SelectedTicket != null && SelectedTicket.Status == "Active";
        }

        private void ExecuteCancelTicket(object parameter)
        {
            var result = MessageBox.Show(
                "Are you sure you want to cancel this ticket?",
                "Confirm Cancellation",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                _dataService.CancelTicket(SelectedTicket.TicketId);
                LoadTickets();

                MessageBox.Show("Ticket cancelled successfully.", "Success",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ExecuteRefresh(object parameter)
        {
            LoadTickets();
        }
    }
}
