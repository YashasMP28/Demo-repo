﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;

namespace RailwayManagementSystem.ViewModels
{
    public class BookTicketViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private ObservableCollection<Route> _routes;
        private Route _selectedRoute;
        private string _passengerName;

        public BookTicketViewModel()
        {
            _dataService = new JsonDataService();
            LoadRoutes();

            BookCommand = new RelayCommand(ExecuteBook, CanExecuteBook);
            RefreshCommand = new RelayCommand(ExecuteRefresh);
        }

        public ObservableCollection<Route> Routes
        {
            get => _routes;
            set => SetProperty(ref _routes, value);
        }

        public Route SelectedRoute
        {
            get => _selectedRoute;
            set
            {
                if (SetProperty(ref _selectedRoute, value))
                {
                    OnPropertyChanged(nameof(RouteInformation));
                }
            }
        }

        public string PassengerName
        {
            get => _passengerName;
            set => SetProperty(ref _passengerName, value);
        }

        public string RouteInformation
        {
            get
            {
                if (SelectedRoute == null) return "Select a route to view details";
                return $"Train: {SelectedRoute.TrainName}\n" +
                       $"From: {SelectedRoute.Source}\n" +
                       $"To: {SelectedRoute.Destination}\n" +
                       $"Date: {SelectedRoute.Date:dd/MM/yyyy}\n" +
                       $"Cost: Rs. {SelectedRoute.Cost}";
            }
        }

        public ICommand BookCommand { get; }
        public ICommand RefreshCommand { get; }

        private void LoadRoutes()
        {
            var allRoutes = _dataService.GetAllRoutes();
            Routes = new ObservableCollection<Route>(allRoutes);
        }

        private bool CanExecuteBook(object parameter)
        {
            return SelectedRoute != null && !string.IsNullOrWhiteSpace(PassengerName);
        }

        private void ExecuteBook(object parameter)
        {
            if (AuthenticationService.CurrentUser == null)
            {
                MessageBox.Show("Please log in to book tickets.", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var ticket = new Ticket
            {
                RouteId = SelectedRoute.Id,
                UserId = AuthenticationService.CurrentUser.Id,
                PassengerName = PassengerName,
                Amount = SelectedRoute.Cost,
                TrainName = SelectedRoute.TrainName,
                Source = SelectedRoute.Source,
                Destination = SelectedRoute.Destination,
                TravelDate = SelectedRoute.Date
            };

            _dataService.AddTicket(ticket);

            MessageBox.Show("Ticket booked successfully!", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);

            PassengerName = string.Empty;
            SelectedRoute = null;
        }

        private void ExecuteRefresh(object parameter)
        {
            LoadRoutes();
        }
    }
}
