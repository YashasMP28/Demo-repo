﻿using RailwayManagementSystem.Commands;
using RailwayManagementSystem.Models;
using RailwayManagementSystem.Services;
using RailwayManagementSystem.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace RailwayManagementSystem.ViewModels
{
    public class SignUpViewModel : BaseViewModel
    {
        private readonly JsonDataService _dataService;
        private string _username;
        private string _email;
        private string _password;
        private string _address;
        private string _phone;
        private string _gender = "Male";
        private string _errorMessage;

        public SignUpViewModel()
        {
            _dataService = new JsonDataService();

            RegisterCommand = new RelayCommand(ExecuteRegister, CanExecuteRegister);
            CancelCommand = new RelayCommand(ExecuteCancel);

            // -------- NEWLY ADDED CODE --------
            GoToLoginCommand = new RelayCommand(ExecuteGoToLogin);
            // -------- END OF NEWLY ADDED CODE --------
        }

        public string Username
        {
            get => _username;
            set => SetProperty(ref _username, value);
        }

        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value);
        }

        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }

        public string Address
        {
            get => _address;
            set => SetProperty(ref _address, value);
        }

        public string Phone
        {
            get => _phone;
            set => SetProperty(ref _phone, value);
        }

        public string Gender
        {
            get => _gender;
            set => SetProperty(ref _gender, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public ICommand RegisterCommand { get; }
        public ICommand CancelCommand { get; }

        // -------- NEWLY ADDED CODE --------
        /// <summary>
        /// Command to navigate back to Login window
        /// Fixes the "Login Here" button functionality
        /// </summary>
        public ICommand GoToLoginCommand { get; }
        // -------- END OF NEWLY ADDED CODE --------

        private bool CanExecuteRegister(object parameter)
        {
            return !string.IsNullOrWhiteSpace(Username) &&
                   !string.IsNullOrWhiteSpace(Email) &&
                   !string.IsNullOrWhiteSpace(Password) &&
                   !string.IsNullOrWhiteSpace(Address) &&
                   !string.IsNullOrWhiteSpace(Phone);
        }

        private void ExecuteRegister(object parameter)
        {
            var existingUser = _dataService.GetUserByEmail(Email);
            if (existingUser != null)
            {
                ErrorMessage = "Email already exists. Please use a different email.";
                return;
            }

            var newUser = new User
            {
                Username = Username,
                Email = Email,
                Password = Password,
                Address = Address,
                Phone = Phone,
                Gender = Gender
            };

            _dataService.AddUser(newUser);

            MessageBox.Show("Registration successful! You can now log in.", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);

            {
                var LoginWindow = new LoginWindow();
                LoginWindow.Show();
                CloseSignUpWindow();
            }
        }

        private void CloseSignUpWindow()
        {
            foreach (Window w in Application.Current.Windows)
                if (w is SignUpWindow) { w.Close(); break; }
        }

        private void ExecuteCancel(object parameter)
        {
            var window = parameter as Window;
            window?.Close();
        }

        // -------- NEWLY ADDED CODE --------
        /// <summary>
        /// Navigates from SignUp to Login window
        /// Purpose: Allows existing users to go back to login without completing signup
        /// This fixes the "Login Here" / "Sign IN here" button bug
        /// </summary>
        private void ExecuteGoToLogin(object parameter)
        {
            try
            {
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                CloseSignUpWindow();
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Error navigating to login: {ex.Message}";
                Console.WriteLine($"Navigation error: {ex.Message}");
            }
        }
        // -------- END OF NEWLY ADDED CODE --------
    }
}