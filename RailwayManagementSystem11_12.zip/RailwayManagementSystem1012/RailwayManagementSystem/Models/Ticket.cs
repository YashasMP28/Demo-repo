﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RailwayManagementSystem.Models
{
    public class Ticket
    {
        public int TicketId { get; set; }
        public int RouteId { get; set; }
        public int UserId { get; set; }
        public string PassengerName { get; set; }
        public DateTime BookingDate { get; set; }
        public string Status { get; set; } 
        public decimal Amount { get; set; }
        public string TrainName { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime TravelDate { get; set; }
        public string TrainId { get; set; }
        public DateTime Date { get; set; }
        public decimal Cost { get; set; }

    }
}
