﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RailwayManagementSystem.Models
{
    public class Train
    {
        public int TrainId { get; set; }
        public string TrainName { get; set; }
        public int TotalSeats { get; set; }
        public int AvailableSeats { get; set; }
        public string OperationalStatus { get; set; }
    }
}
