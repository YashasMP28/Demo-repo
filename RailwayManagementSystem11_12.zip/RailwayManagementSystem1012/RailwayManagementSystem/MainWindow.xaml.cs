﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RailwayManagementSystem.Services;
using RailwayManagementSystem.Views;

namespace RailwayManagementSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeUser();

            
            if (AuthenticationService.CurrentUser?.IsAdmin == true)
            {
                MainFrame.Navigate(new AdminRoutesView());
            }
            else
            {
                MainFrame.Navigate(new SearchRoutesView());
            }
        }

        private void InitializeUser()
        {
            if (AuthenticationService.CurrentUser != null)
            {
                UserNameTextBlock.Text = $"Welcome, {AuthenticationService.CurrentUser.Username}";

                if (AuthenticationService.CurrentUser.IsAdmin)
                {
                    UserMenuPanel.Visibility = Visibility.Collapsed;
                    AdminMenuPanel.Visibility = Visibility.Visible;
                }
                else
                {
                    UserMenuPanel.Visibility = Visibility.Visible;
                    AdminMenuPanel.Visibility = Visibility.Collapsed;
                }
            }
        }

        // User menu navigation
        private void SearchRoutes_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new SearchRoutesView());
        }

        private void BookTickets_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new BookTicketView());
        }

        private void MyHistory_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new MyHistoryView());
        }

        // Admin menu navigation
        private void AdminTrains_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AdminTrainsView());
        }

        private void AdminRoutes_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AdminRoutesView());
        }

        private void AdminTickets_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AdminTicketsView());
        }

        private void AdminPassengers_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AdminPassengersView());
        }

       
        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to log out?",
                "Confirm Logout",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                AuthenticationService.CurrentUser = null;

                var loginWindow = new LoginWindow();
                loginWindow.Show();
                //LoginWindow();
                this. Close();
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}