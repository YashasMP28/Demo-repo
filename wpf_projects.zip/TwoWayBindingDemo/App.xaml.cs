using System.Windows;

namespace TwoWayBindingDemo
{
    public partial class App : Application
    {
    }
}
