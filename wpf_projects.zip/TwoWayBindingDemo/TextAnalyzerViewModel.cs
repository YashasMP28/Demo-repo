using System.ComponentModel;
using System.Linq;
using System.Text;

namespace TwoWayBindingDemo
{
    public class TextAnalyzerViewModel : INotifyPropertyChanged
    {
        private string inputText = string.Empty;
        private string analysisResult = string.Empty;

        public string InputText
        {
            get => inputText;
            set
            {
                if (inputText == value) return;
                inputText = value;
                OnPropertyChanged(nameof(InputText));
            }
        }

        public string AnalysisResult
        {
            get => analysisResult;
            set
            {
                if (analysisResult == value) return;
                analysisResult = value;
                OnPropertyChanged(nameof(AnalysisResult));
            }
        }

        public void AnalyzeText()
        {
            if (string.IsNullOrEmpty(InputText))
            {
                AnalysisResult = "Please enter some text.";
                return;
            }

            int total = InputText.Length;
            int upper = InputText.Count(char.IsUpper);
            int lower = InputText.Count(char.IsLower);
            int digits = InputText.Count(char.IsDigit);
            int special = InputText.Count(ch => !char.IsLetterOrDigit(ch));

            var sb = new StringBuilder();
            sb.AppendLine($"Total Letters: {total}");
            sb.AppendLine($"Uppercase Letters: {upper}");
            sb.AppendLine($"Lowercase Letters: {lower}");
            sb.AppendLine($"Numbers: {digits}");
            sb.AppendLine($"Special Characters: {special}");

            AnalysisResult = sb.ToString();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
