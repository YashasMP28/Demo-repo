using System.Windows;

namespace TwoWayBindingDemo
{
    public partial class MainWindow : Window
    {
        private TextAnalyzerViewModel viewModel;

        public MainWindow()
        {
            InitializeComponent();
            viewModel = new TextAnalyzerViewModel();
            this.DataContext = viewModel;
        }

        private void AnalyzeButton_Click(object sender, RoutedEventArgs e)
        {
            viewModel.AnalyzeText();
        }
    }
}
