using System.Windows;

namespace DependencyPropertyDemo
{
    public partial class App : Application
    {
    }
}
