using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace DependencyPropertyDemo
{
    // A simple control that inherits TextBlock and exposes a DependencyProperty "InputText".
    // When InputText changes, the control analyzes the text and updates its own Text to show counts.
    public class TextAnalysisControl : TextBlock
    {
        public static readonly DependencyProperty InputTextProperty =
            DependencyProperty.Register(
                nameof(InputText),
                typeof(string),
                typeof(TextAnalysisControl),
                new PropertyMetadata(string.Empty, OnInputTextChanged));

        // CLR wrapper for easier usage in code-behind
        public string InputText
        {
            get => (string)GetValue(InputTextProperty);
            set => SetValue(InputTextProperty, value);
        }

        private static void OnInputTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as TextAnalysisControl;
            string text = e.NewValue as string ?? string.Empty;

            int total = text.Length;
            int upper = text.Count(char.IsUpper);
            int lower = text.Count(char.IsLower);
            int digits = text.Count(char.IsDigit);
            int special = text.Count(ch => !char.IsLetterOrDigit(ch));

            var sb = new StringBuilder();
            sb.AppendLine($"Total Letters: {total}");
            sb.AppendLine($"Uppercase Letters: {upper}");
            sb.AppendLine($"Lowercase Letters: {lower}");
            sb.AppendLine($"Numbers: {digits}");
            sb.AppendLine($"Special Characters: {special}");

            control.Text = sb.ToString();
        }
    }
}
