using System.Windows;

namespace DependencyPropertyDemo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ClickButton_Click(object sender, RoutedEventArgs e)
        {
            // Pass the text from TextBox to our Dependency Property
            AnalyzerControl.InputText = InputBox.Text;
        }
    }
}
