Two WPF sample projects (built for .NET 8 WPF):
1) DependencyPropertyDemo - demonstrates a custom DependencyProperty (InputText) on a TextAnalysisControl.
2) TwoWayBindingDemo - demonstrates Two-Way binding between a TextBox and a ViewModel (InputText).

Open each folder in Visual Studio 2022 or later and run the project.
